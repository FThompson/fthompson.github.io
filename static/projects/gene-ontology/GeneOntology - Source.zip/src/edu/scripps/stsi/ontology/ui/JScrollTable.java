package edu.scripps.stsi.ontology.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Created by Finn on 5/29/2014.
 */
public class JScrollTable extends JTable {

    public JScrollTable(DefaultTableModel model) {
        super(model);
    }

    public boolean getScrollableTracksViewportWidth(){
        return getPreferredSize().width < getParent().getWidth();
    }
}
