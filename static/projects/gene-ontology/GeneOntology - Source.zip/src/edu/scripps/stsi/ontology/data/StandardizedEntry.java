package edu.scripps.stsi.ontology.data;

/**
 * Created by Finn on 5/29/2014.
 */
public class StandardizedEntry implements Comparable<StandardizedEntry> {

    private final String gene;
    private final String diseaseTerms;
    private final String displayTerm;
    private final String inheritanceMode;
    private final String filterTerms;
    private final String reportTerms;
    private final String confidence;
    private final String sourceLinks;
    private final String approvedSymbol;

    public StandardizedEntry(String gene, String diseaseTerms, String displayTerm, String inheritanceMode, String filterTerms,
                             String reportTerms, String confidence, String sourceLinks, String approvedSymbol) {
        this.gene = gene;
        this.diseaseTerms = diseaseTerms;
        this.displayTerm = displayTerm;
        this.inheritanceMode = inheritanceMode;
        this.filterTerms = filterTerms;
        this.reportTerms = reportTerms;
        this.confidence = confidence;
        this.sourceLinks = sourceLinks;
        this.approvedSymbol = approvedSymbol;
    }

    public String getGene() {
        return gene;
    }

    public String getDiseaseTerms() {
        return diseaseTerms;
    }

    public String getDisplayTerm() {
        return displayTerm;
    }

    public String getInheritanceMode() {
        return inheritanceMode;
    }

    public String getFilterTerms() {
        return filterTerms;
    }

    public String getReportTerms() {
        return reportTerms;
    }

    public String getConfidence() {
        return confidence;
    }

    public String getSourceLinks() {
        return sourceLinks;
    }

    public String getApprovedSymbol() {
        return approvedSymbol;
    }

    public String[] getSymptoms() {
        return diseaseTerms.toLowerCase().split(",?[/&\\s]+");
    }

    public Object[] toData() {
        return new Object[]{gene, diseaseTerms, displayTerm, inheritanceMode, filterTerms, reportTerms, confidence, sourceLinks, approvedSymbol};
    }

    @Override
    public String toString() {
        return gene + " - " + diseaseTerms;
    }

    @Override
    public int compareTo(StandardizedEntry o) {
        return this.toString().compareTo(o.toString());
    }
}
