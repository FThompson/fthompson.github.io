package edu.scripps.stsi.ontology;

import edu.scripps.stsi.ontology.ui.OntologyUI;

import javax.swing.*;

/**
 * Created by Finn on 5/28/2014.
 */
public class Application {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                OntologyUI ui = new OntologyUI();
                ui.setVisible(true);
            }
        });
    }
}
