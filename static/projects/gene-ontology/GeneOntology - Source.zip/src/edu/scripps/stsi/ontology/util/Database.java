package edu.scripps.stsi.ontology.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Database {

	private static Map<String, Serializable> data = new HashMap<>();
    private static File database = null;
    private static final String NAME = "STSIOntology";
	
	public static Serializable getProperty(String key) {
		return data.get(key);
	}
	
	public static void setProperty(String key, Serializable value) {
		data.put(key, value);
	}
	
	public static void remove(String key) {
		data.remove(key);
	}
	
	public static void store() {
		if (!database.exists()) {
			try {
				database.createNewFile();
			} catch (IOException e) {
				System.err.println("Unable to create database file: " + e.getMessage());
				return;
			}
		}
		if (!database.canWrite()) {
			database.setWritable(true);
		}
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(database))) {
        	out.writeObject(data);
		} catch (IOException e) {
			System.err.println("Failed to store database file: " + e.getMessage());
		}
	}

    @SuppressWarnings("unchecked")
	private static void load() {
		if (database.exists()) {
			if (!database.canRead()) {
				database.setReadable(true);
			}
			try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(database))) {
			    data = (Map<String, Serializable>) in.readObject();
			} catch (Exception e) {
				System.err.println("Failed to load database file: " + e.getMessage());
				database.delete();
			}
		}
	}

    public static boolean isEmpty() {
        return data.isEmpty();
    }

    public static File getDatabaseFile() {
        return database;
    }

    private static String getUnixHome() {
        return System.getProperty("user.home", "~");
    }
	
	static {
        String path;
        if (System.getProperty("os.name").contains("Win")) {
            path = System.getenv("APPDATA") + File.separator + NAME + ".db";
        } else {
            path = getUnixHome() + File.separator + "." + NAME.toLowerCase() + "data";
        }
        database = new File(path);
		load();
	}

}
