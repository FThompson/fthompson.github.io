package edu.scripps.stsi.ontology.ui;

import edu.scripps.stsi.ontology.data.StandardizedEntry;
import edu.scripps.stsi.ontology.data.UnstandardizedEntry;
import edu.scripps.stsi.ontology.util.Database;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.*;
import java.util.List;

/**
 * Created by Finn on 5/29/2014.
 */
public class OntologyUI extends JFrame {

    private File spreadsheet;
    private JTable scores;
    private JTable ignores;
    private JTable synonyms;
    private JTable standardized;
    private JTable unstandardized;
    private JTextField sTermInput;
    private JTextField ignoreInput;
    private JTextField synonymInput;
    private JLabel input;
    private JLabel standardizedDataInput;
    private JLabel unstandardizedDataInput;
    private TreeSet<String> ignoredTerms = new TreeSet<>();
    private TreeMap<String, String> termSynonyms = new TreeMap<>();
    private SortedSet<Map.Entry<StandardizedEntry, Double>> weights;
    private StandardizedEntry[] standardizedEntries = new StandardizedEntry[0];
    private UnstandardizedEntry[] unstandardizedEntries = new UnstandardizedEntry[0];

    public OntologyUI() {
        if (Database.isEmpty()) {
            initializeTerms();
        } else {
            ignoredTerms = (TreeSet<String>) Database.getProperty("ignoredTerms");
            termSynonyms = (TreeMap<String, String>) Database.getProperty("termSynonyms");
        }
        Database.setProperty("ignoredTerms", ignoredTerms);
        Database.setProperty("termSynonyms", termSynonyms);

        setTitle("Ontology Curation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane content = new JTabbedPane();
        add(content);

        JPanel results = new JPanel();
        results.setLayout(new BoxLayout(results, BoxLayout.Y_AXIS));
        content.addTab("Search Results", results);

        DefaultTableModel _scores = new DefaultTableModel();
        _scores.addColumn("Relevance");
        _scores.addColumn("Gene");
        _scores.addColumn("Disease Terms");
        _scores.addColumn("Display Term");
        _scores.addColumn("Inheritance Mode");
        _scores.addColumn("Filter Terms");
        _scores.addColumn("Report Terms");
        _scores.addColumn("Confidence");
        _scores.addColumn("GeneTests~GeneReview~OMIM~PubMed");
        _scores.addColumn("Approved Symbol");
        scores = new JScrollTable(_scores);
        scores.getColumn("Gene").setMinWidth(60);
        scores.getColumn("Gene").setMaxWidth(70);
        scores.getColumn("Relevance").setMinWidth(70);
        scores.getColumn("Relevance").setMaxWidth(100);
        scores.getColumn("Relevance").setCellRenderer(new DecimalCellRenderer());
        scores.getTableHeader().setReorderingAllowed(false);
        scores.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        results.add(new JScrollPane(scores));

        JPanel resultsControls = new JPanel();
        resultsControls.setLayout(new BoxLayout(resultsControls, BoxLayout.X_AXIS));
        resultsControls.setBorder(new EmptyBorder(0, 5, 0, 5));
        results.add(resultsControls);

        JPanel selection = new JPanel();
        selection.setBorder(new EmptyBorder(0, 0, 0, 10));
        selection.setLayout(new BoxLayout(selection, BoxLayout.Y_AXIS));
        JLabel info = new JLabel("Relevance scores for:");
        selection.add(info);
        input = new JLabel("(choose an input from the unstandardized table)");
        selection.add(input);
        resultsControls.add(selection);
        resultsControls.add(Box.createHorizontalGlue());

        JButton export = new JButton(new ExportAction());
        resultsControls.add(export);
        JButton normalize = new JButton(new NormalizeAction());
        resultsControls.add(normalize);

        JPanel standardizedData = new JPanel();
        standardizedData.setLayout(new BoxLayout(standardizedData, BoxLayout.Y_AXIS));
        content.addTab("Standardized Data", standardizedData);

        DefaultTableModel _standardized = new DefaultTableModel();
        _standardized.addColumn("Gene");
        _standardized.addColumn("Disease Terms");
        _standardized.addColumn("Display Term");
        _standardized.addColumn("Inheritance Mode");
        _standardized.addColumn("Filter Terms");
        _standardized.addColumn("Report Terms");
        _standardized.addColumn("Confidence");
        _standardized.addColumn("GeneTests~GeneReview~OMIM~PubMed");
        _standardized.addColumn("Approved Symbol");
        standardized = new JScrollTable(_standardized);
        standardized.getColumn("Gene").setMinWidth(60);
        standardized.getColumn("Gene").setMaxWidth(70);
        standardized.getTableHeader().setReorderingAllowed(false);
        standardized.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        standardizedData.add(new JScrollPane(standardized));

        JPanel standardizedDataControls = new JPanel();
        standardizedDataControls.setLayout(new BoxLayout(standardizedDataControls, BoxLayout.X_AXIS));
        standardizedDataControls.setBorder(new EmptyBorder(0, 5, 0, 5));
        standardizedData.add(standardizedDataControls);

        JPanel standardizedFileInfo = new JPanel();
        standardizedFileInfo.setBorder(new EmptyBorder(0, 0, 0, 10));
        standardizedFileInfo.setLayout(new BoxLayout(standardizedFileInfo, BoxLayout.Y_AXIS));
        JLabel standardizedDataInfo = new JLabel("Displaying data from spreadsheet:");
        standardizedFileInfo.add(standardizedDataInfo);
        standardizedDataInput = new JLabel("(choose an Excel spreadsheet file using the Load button)");
        standardizedFileInfo.add(standardizedDataInput);
        standardizedDataControls.add(standardizedFileInfo);
        standardizedDataControls.add(Box.createHorizontalGlue());

        JButton standardizedDataLoad = new JButton(new LoadAction());
        standardizedDataControls.add(standardizedDataLoad);

        JPanel unstandardizedData = new JPanel();
        unstandardizedData.setLayout(new BoxLayout(unstandardizedData, BoxLayout.Y_AXIS));
        content.addTab("Unstandardized Data", unstandardizedData);

        DefaultTableModel _unstandardized = new DefaultTableModel();
        _unstandardized.addColumn("Gene");
        _unstandardized.addColumn("Disease Terms");
        unstandardized = new JScrollTable(_unstandardized);
        unstandardized.getColumn("Gene").setMinWidth(60);
        unstandardized.getColumn("Gene").setMaxWidth(70);
        unstandardized.getTableHeader().setReorderingAllowed(false);
        unstandardized.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        unstandardized.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        unstandardizedData.add(new JScrollPane(unstandardized));

        JPanel unstandardizedDataControls = new JPanel();
        unstandardizedDataControls.setLayout(new BoxLayout(unstandardizedDataControls, BoxLayout.X_AXIS));
        unstandardizedDataControls.setBorder(new EmptyBorder(0, 5, 0, 5));
        unstandardizedData.add(unstandardizedDataControls);

        JPanel unstandardizedFileInfo = new JPanel();
        unstandardizedFileInfo.setBorder(new EmptyBorder(0, 0, 0, 10));
        unstandardizedFileInfo.setLayout(new BoxLayout(unstandardizedFileInfo, BoxLayout.Y_AXIS));
        JLabel unstandardizedDataInfo = new JLabel("Displaying data from spreadsheet:");
        unstandardizedFileInfo.add(unstandardizedDataInfo);
        unstandardizedDataInput = new JLabel("(choose an Excel spreadsheet file using the Load button)");
        unstandardizedFileInfo.add(unstandardizedDataInput);
        unstandardizedDataControls.add(unstandardizedFileInfo);
        unstandardizedDataControls.add(Box.createHorizontalGlue());

        JButton analyze = new JButton(new AnalyzeAction());
        unstandardizedDataControls.add(analyze);
        JButton unstandardizedDataLoad = new JButton(new LoadAction());
        unstandardizedDataControls.add(unstandardizedDataLoad);

        JSplitPane settings = new JSplitPane();
        settings.setResizeWeight(0.25);
        content.addTab("Settings", settings);

        JPanel ignoreSettings = new JPanel();
        ignoreSettings.setLayout(new BoxLayout(ignoreSettings, BoxLayout.Y_AXIS));
        settings.setLeftComponent(ignoreSettings);

        DefaultTableModel _ignores = new DefaultTableModel();
        _ignores.addColumn("Ignored Term");
        for (String ignoredTerm : ignoredTerms) {
            _ignores.addRow(new Object[]{ignoredTerm});
        }
        ignores = new JScrollTable(_ignores);
        ignores.getColumn("Ignored Term").setMinWidth(100);
        ignores.getTableHeader().setReorderingAllowed(false);
        ignores.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        ignoreSettings.add(new JScrollPane(ignores));

        JLabel ignoreLabel = new JLabel("Ignore:");
        ignoreSettings.add(ignoreLabel);
        ignoreInput = new JTextField();
        ignoreSettings.add(ignoreInput);
        JButton addIgnore = new JButton(new AddIgnoreAction());
        ignoreSettings.add(addIgnore);
        JButton removeIgnore = new JButton(new RemoveIgnoreAction());
        ignoreSettings.add(removeIgnore);

        JPanel synonymSettings = new JPanel();
        synonymSettings.setAlignmentX(JPanel.CENTER_ALIGNMENT);
        synonymSettings.setLayout(new BoxLayout(synonymSettings, BoxLayout.Y_AXIS));
        settings.setRightComponent(synonymSettings);

        DefaultTableModel _synonyms = new DefaultTableModel();
        _synonyms.addColumn("Term");
        _synonyms.addColumn("Synonym");
        for (Map.Entry<String, String> synonym : termSynonyms.entrySet()) {
            _synonyms.addRow(new Object[]{synonym.getKey(), synonym.getValue()});
        }
        synonyms = new JScrollTable(_synonyms);
        synonyms.getColumn("Term").setMinWidth(100);
        synonyms.getColumn("Synonym").setMinWidth(100);
        synonyms.getTableHeader().setReorderingAllowed(false);
        synonyms.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        synonymSettings.add(new JScrollPane(synonyms));

        JLabel termLabel = new JLabel("Term:");
        synonymSettings.add(termLabel);
        sTermInput = new JTextField();
        synonymSettings.add(sTermInput);
        JLabel synonymLabel = new JLabel("Synonym:");
        synonymSettings.add(synonymLabel);
        synonymInput = new JTextField();
        synonymSettings.add(synonymInput);
        JButton addSynonym = new JButton(new AddSynonymAction());
        synonymSettings.add(addSynonym);
        JButton removeSynonym = new JButton(new RemoveSynonymAction());
        synonymSettings.add(removeSynonym);

        pack();
        settings.setDividerLocation(0.25);
        setLocationRelativeTo(null);
    }

    public void refreshTableData() {
        DefaultTableModel _standardized = (DefaultTableModel) standardized.getModel();
        _standardized.setRowCount(0);
        for (StandardizedEntry entry : standardizedEntries) {
            _standardized.addRow(entry.toData());
        }
        DefaultTableModel _unstandardized = (DefaultTableModel) unstandardized.getModel();
        _unstandardized.setRowCount(0);
        for (UnstandardizedEntry entry : unstandardizedEntries) {
            _unstandardized.addRow(entry.toData());
        }
    }
    
    private void initializeTerms() {
        ignoredTerms.add("with");
        ignoredTerms.add("and");
        ignoredTerms.add("of");
        ignoredTerms.add("type");
        ignoredTerms.add("in");
        ignoredTerms.add("to");
        ignoredTerms.add("without");
        ignoredTerms.add("or");
        ignoredTerms.add("the");

        termSynonyms.put("tumour", "tumor");
        termSynonyms.put("tumours", "tumors");
        termSynonyms.put("tumoural", "tumoral");
        termSynonyms.put("carcinoma", "cancer");
        termSynonyms.put("assoc", "association");
    }

    public static class DecimalCellRenderer extends DefaultTableCellRenderer {

        private static final DecimalFormat formatter = new DecimalFormat("0.0000");

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            value = formatter.format((Number) value);
            return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        }
    }

    public class AddIgnoreAction extends AbstractAction {

        public AddIgnoreAction() {
            super("Add ignored term");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String term = ignoreInput.getText();
            if (!ignoredTerms.contains(term)) {
                ignoredTerms.add(term);
                ((DefaultTableModel) ignores.getModel()).addRow(new Object[]{term});
                ignoreInput.setText("");
                Database.store();
            } else {
                JOptionPane.showMessageDialog(OntologyUI.this, "Term already ignored", "Notice", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    public class AddSynonymAction extends AbstractAction {

        public AddSynonymAction() {
            super("Add synonym");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String term = sTermInput.getText();
            String synonym = synonymInput.getText();
            if (!termSynonyms.containsKey(term)) {
                termSynonyms.put(term, synonym);
                ((DefaultTableModel) synonyms.getModel()).addRow(new Object[]{term, synonym});
                sTermInput.setText("");
                synonymInput.setText("");
                Database.store();
            } else {
                JOptionPane.showMessageDialog(OntologyUI.this, "Synonym already exists", "Notice", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    public class RemoveIgnoreAction extends AbstractAction {

        public RemoveIgnoreAction() {
            super("Remove selection");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            DefaultTableModel _ignores = (DefaultTableModel) ignores.getModel();
            for (int row : ignores.getSelectedRows()) {
                String term = (String) _ignores.getValueAt(row, 0);
                ignoredTerms.remove(term);
                _ignores.removeRow(row);
            }
            Database.store();
        }
    }

    public class RemoveSynonymAction extends AbstractAction {

        public RemoveSynonymAction() {
            super("Remove selection");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            DefaultTableModel _synonyms = (DefaultTableModel) synonyms.getModel();
            for (int row : synonyms.getSelectedRows()) {
                String term = (String) _synonyms.getValueAt(row, 0);
                termSynonyms.remove(term);
                _synonyms.removeRow(row);
            }
            Database.store();
        }
    }

    public class ExportAction extends AbstractAction {

        public ExportAction() {
            super("Export results");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (scores.getRowCount() == 0) {
                JOptionPane.showMessageDialog(OntologyUI.this, "No search result data loaded", "Notice", JOptionPane.ERROR_MESSAGE);
                return;
            }
            File export = new File(spreadsheet.getParentFile(), input.getText() + ".txt");
            try (PrintWriter out = new PrintWriter(export)) {
                for (int c = 0; c < scores.getColumnCount(); c++) {
                    out.print(scores.getColumnName(c));
                    out.print(",");
                }
                out.println();
                for (int r = 0; r < scores.getRowCount(); r++) {
                    for (int c = 0; c < scores.getColumnCount(); c++) {
                        out.print(scores.getValueAt(r, c));
                        out.print(",");
                    }
                    out.println();
                }
                JOptionPane.showMessageDialog(OntologyUI.this, "Exported results to " + export.getAbsolutePath(), "Notice", JOptionPane.PLAIN_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(OntologyUI.this, "Failed to export results", "Notice", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    public class NormalizeAction extends AbstractAction {

        public NormalizeAction() {
            super("Normalize results");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (scores.getRowCount() == 0) {
                JOptionPane.showMessageDialog(OntologyUI.this, "No search result data loaded", "Notice", JOptionPane.ERROR_MESSAGE);
                return;
            }
            DefaultTableModel _scores = (DefaultTableModel) scores.getModel();
            _scores.setRowCount(0);
            for (int i = 0; i < _scores.getRowCount(); i++) {
                _scores.removeRow(i);
            }
            double min = weights.last().getValue();
            double max = weights.first().getValue();
            double range = max - min;
            for (Map.Entry<StandardizedEntry, Double> entry : weights) {
                Object[] data = entry.getKey().toData();
                Object[] row = new Object[data.length + 1];
                row[0] = (entry.getValue() - min) / range;
                System.arraycopy(data, 0, row, 1, data.length);
                _scores.addRow(row);
            }
        }
    }

    public class AnalyzeAction extends AbstractAction {

        public AnalyzeAction() {
            super("Search selected entry");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int selected = unstandardized.getSelectedRow();
            if (selected == -1) {
                JOptionPane.showMessageDialog(OntologyUI.this, "No unstandardized data row selected", "Notice", JOptionPane.WARNING_MESSAGE);
                return;
            }

            UnstandardizedEntry search = unstandardizedEntries[selected];
            input.setText(search.toString());
            String searchGene = search.getGene();
            String[] searchSymptoms = search.getSymptoms();

            Map<String, Integer> termFreqs = new HashMap<>();
            for (StandardizedEntry entry : standardizedEntries) {
                String gene = entry.getGene();
                termFreqs.put(gene, termFreqs.containsKey(gene) ? termFreqs.get(gene) + 1 : 1);
                String[] symptoms = entry.getSymptoms();
                for (String symptom : symptoms) {
                    if (!ignoredTerms.contains(symptom)) {
                        if (termSynonyms.containsKey(symptom)) {
                            symptom = termSynonyms.get(symptom);
                        }
                        termFreqs.put(symptom, termFreqs.containsKey(symptom) ? termFreqs.get(symptom) + 1 : 1);
                    }
                }
            }

            Map<StandardizedEntry, Double> _weights = new HashMap<>();
            for (StandardizedEntry entry : standardizedEntries) {
                String gene = entry.getGene();
                String[] symptoms = entry.getSymptoms();
                double weight = 0;
                double geneTF = (searchGene.equals(gene) ? 0.5 : 0); // modified half weight for gene
                double geneIDF = Math.log10((double) standardizedEntries.length / termFreqs.get(gene));
                double geneTFIDF = geneTF * geneIDF;
                weight += geneTFIDF;
                for (String searchSymptom : searchSymptoms) {
                    if (ignoredTerms.contains(searchSymptom) || !termFreqs.containsKey(searchSymptom)) {
                        continue;
                    }
                    if (termSynonyms.containsKey(searchSymptom)) {
                        searchSymptom = termSynonyms.get(searchSymptom);
                    }
                    int freq = 0;
                    for (String symptom : symptoms) {
                        if (searchSymptom.equals(symptom)) {
                            freq++;
                        }
                    }
                    double tf = (double) freq / symptoms.length;
                    double idf = Math.log10((double) standardizedEntries.length / termFreqs.get(searchSymptom));
                    double tfidf = tf * idf;
                    weight += tfidf;
                }
                _weights.put(entry, weight);
            }
            weights = entriesSortedByValues(_weights);
            DefaultTableModel _scores = (DefaultTableModel) scores.getModel();
            _scores.setRowCount(0);
            for (Map.Entry<StandardizedEntry, Double> entry : weights) {
                Object[] data = entry.getKey().toData();
                Object[] row = new Object[data.length + 1];
                row[0] = entry.getValue();
                System.arraycopy(data, 0, row, 1, data.length);
                _scores.addRow(row);
            }
        }

        public <K, V extends Comparable<? super V>> SortedSet<Map.Entry<K, V>> entriesSortedByValues(Map<K,V> map) {
            SortedSet<Map.Entry<K,V>> sortedEntries = new TreeSet<Map.Entry<K,V>>(new Comparator<Map.Entry<K, V>>() {
                @Override
                public int compare(Map.Entry<K, V> e1, Map.Entry<K, V> e2) {
                    int res = e2.getValue().compareTo(e1.getValue());
                    if (e1.getKey() instanceof Comparable) {
                        return res != 0 ? res : ((Comparable) e1.getKey()).compareTo(e2.getKey());
                    }
                    return res != 0 ? res : 1;
                }
            });
            sortedEntries.addAll(map.entrySet());
            return sortedEntries;
        }
    }

    public class LoadAction extends AbstractAction {

        public LoadAction() {
            super("Load spreadsheet");
        }

        public String getStringCellValue(Cell cell) {
            return cell != null ? cell.getStringCellValue() : "";
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser chooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel spreadsheets (.xlsx, .xlsm)", "xlsx", "xlsm");
            chooser.setFileFilter(filter);
            int ret = chooser.showOpenDialog(null);
            if (ret == JFileChooser.APPROVE_OPTION) {
                try {
                    spreadsheet = chooser.getSelectedFile();
                    Workbook workbook = new XSSFWorkbook(new FileInputStream(spreadsheet));
                    Sheet standardized = workbook.getSheet("standardized");
                    List<StandardizedEntry> standardizedList = new ArrayList<>();
                    for (int i = 1; i < standardized.getPhysicalNumberOfRows(); i++) {
                        Row row = standardized.getRow(i);
                        String gene = getStringCellValue(row.getCell(0));
                        String diseaseTerms = getStringCellValue(row.getCell(1));
                        String displayTerms = getStringCellValue(row.getCell(2));
                        String inheritanceMode = getStringCellValue(row.getCell(3));
                        String filterTerms = getStringCellValue(row.getCell(4));
                        String reportTerms = getStringCellValue(row.getCell(5));
                        String confidence = getStringCellValue(row.getCell(6));
                        String sourceLinks = getStringCellValue(row.getCell(7));
                        String approvedSymbol = getStringCellValue(row.getCell(8));
                        standardizedList.add(new StandardizedEntry(gene, diseaseTerms, displayTerms, inheritanceMode,
                                filterTerms, reportTerms, confidence, sourceLinks, approvedSymbol));
                    }
                    standardizedEntries = standardizedList.toArray(new StandardizedEntry[standardizedList.size()]);

                    Sheet unstandardized = workbook.getSheet("unstandardized");
                    List<UnstandardizedEntry> unstandardizedList = new ArrayList<>();
                    for (int i = 0; i < unstandardized.getPhysicalNumberOfRows(); i++) {
                        Row row = unstandardized.getRow(i);
                        String gene = getStringCellValue(row.getCell(0));
                        String diseaseTerms = getStringCellValue(row.getCell(1));
                        unstandardizedList.add(new UnstandardizedEntry(gene, diseaseTerms));
                    }
                    unstandardizedEntries = unstandardizedList.toArray(new UnstandardizedEntry[unstandardizedList.size()]);

                    refreshTableData();
                    input.setText("(choose an input from the unstandardized table)");
                    standardizedDataInput.setText(spreadsheet.getAbsolutePath());
                    unstandardizedDataInput.setText(spreadsheet.getAbsolutePath());
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(OntologyUI.this, "Exception while loading spreadsheet: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        }
    }
}
