package edu.scripps.stsi.ontology.data;

/**
 * Created by Finn on 5/29/2014.
 */
public class UnstandardizedEntry implements Comparable<UnstandardizedEntry> {

    private final String gene;
    private final String diseaseTerms;

    public UnstandardizedEntry(String gene, String diseaseTerms) {
        this.gene = gene;
        this.diseaseTerms = diseaseTerms;
    }

    public String getGene() {
        return gene;
    }

    public String getDiseaseTerms() {
        return diseaseTerms;
    }

    public String[] getSymptoms() {
        return diseaseTerms.toLowerCase().split(",?[/&\\s]+");
    }

    public Object[] toData() {
        return new Object[]{gene, diseaseTerms};
    }

    @Override
    public String toString() {
        return gene + " - " + diseaseTerms;
    }

    @Override
    public int compareTo(UnstandardizedEntry o) {
        return this.toString().compareTo(o.toString());
    }
}
