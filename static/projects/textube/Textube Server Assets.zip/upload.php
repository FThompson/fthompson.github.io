<?php
require_once("includes/build.php");

$root = $_SERVER['DOCUMENT_ROOT'];
$uploads_dir = "$root/textu.be/_uploads";
if (!file_exists($uploads_dir)) {
	mkdir($uploads_dir, 0700);
}
if (get_magic_quotes_gpc()) {
    function stripslashes_gpc(&$value) {
        $value = stripslashes($value);
    }
    array_walk_recursive($_GET, 'stripslashes_gpc');
    array_walk_recursive($_POST, 'stripslashes_gpc');
    array_walk_recursive($_COOKIE, 'stripslashes_gpc');
    array_walk_recursive($_REQUEST, 'stripslashes_gpc');
}
if (isset($_POST['text'])) {
	$text = $_POST['text'];
	build_text($text);
}
if ($_FILES['fileupload']['size'] > 0) {
	if ($_FILES['fileupload']['error'] == UPLOAD_ERR_OK) {
		build_file($_FILES['fileupload']);
	} else {
		die("error in file upload: ".$_FILES['fileupload']['error']);
	}
}

?>