<?php

header("Location: http://textube.org");

?>