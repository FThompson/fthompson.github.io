<!DOCTYPE html>
<html lang="en">
	<?php
	require_once($_SERVER['DOCUMENT_ROOT']."/includes/head.php");
	echo_head("Textube - Home", "style.css");
	?>
	
	<body>
		<div id="content">
			<div id="icon">
				<a href="/"><img src="/images/icon_32.png" /></a>
			</div>
			<div id="panel">
				<button onclick="window.location = 'download.php';">Download Textube</button>
			</div>
		</div>
	</body>
</html>