<?php
require_once($_SERVER['DOCUMENT_ROOT']."/includes/increment.php");

$path = $_SERVER['DOCUMENT_ROOT']."/download/";
$version_path = $path."version.txt";
$version_handle = fopen($version_path, "r");
$line = fgets($version_handle);
fclose($version_handle);
$varr = explode(";", $line);
$version = $varr[0];
$name = "Textube-".str_replace(".", "", $version).".jar";
$download_path = $path.$name;

if ($fd = fopen($download_path, "r")) {
	$fsize = filesize($download_path);
	header("Content-Disposition: attachment; filename=\"".$name."\"");
	header("Content-type: application/java-archive");
	header("Content-length: $fsize");
	header("Cache-control: no-transform");
	readfile($download_path);
}
fclose($fd);

increment_download_count();
?>