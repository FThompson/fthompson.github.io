<html>
	<head>
		<title>Textube Download Statistics</title>
		<meta name="author" content="Finn Thompson" />
		<link rel="Shortcut Icon" href="/favicon.ico" type="image/x-icon" />
		<style type="text/css">
			body {
				background-image:url(/images/background.png);
				background-repeat:repeat;
			}
			a img {
				border-style:none;
			}
			table {
				border-collapse:collapse;
				margin-top:6px;
				border:1px;
				background-color:#FFFFFF;
			}
			th {
				background-color:#50CC1F;
				color:white;
			}
			td {
				text-align:center;
			}
			tr.d0 td {
				background-color:#FFFFFF;
				color:black;
			}
			tr.d1 td {
				background-color:#D5F2C9;
				color:black;
			}
			table,th,td {
				border:1px solid black;
				width:400;
			}
		</style>
	</head>
	<body>
		<center>
			<a href="/community">
				<img src="/images/icon_32.png" alt="Textube Home" />
			</a>
			<table>
				<tr>
					<th>Version</th>
					<th>Release date</th>
					<th>Download count</th>
				</tr>
				<?php
				require_once($_SERVER['DOCUMENT_ROOT']."/includes/strutil.php");
				
				$path = $_SERVER['DOCUMENT_ROOT']."/download/";
				$log_path = $path."download_log.txt";
				$contents = file_get_contents($log_path);
				$log_arr = array_reverse(explode("\n", $contents));
				
				$row_color = true;
				foreach ($log_arr as $log_entry) {
					if (empty($log_entry)) {
						continue;
					}
					$data = explode(":", $log_entry);
					$version = $data[0];
					$jar_path = $path."Textube-".str_replace(".", "", $version).".jar";
					if (file_exists($jar_path)) {
						$creation = gmdate("F d Y", filemtime($jar_path));
					}
					echo
				"<tr class=\"".($row_color ? "d0" : "d1")."\">
					<td>"."Textube v".$version."</td>
					<td>".$creation."</td>
					<td>".insert_commas($data[1])."</td>
				</tr>";
					$row_color = !$row_color;
				}
				
				?>

			</table>
		</center>
	</body>
</html>