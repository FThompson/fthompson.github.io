<!DOCTYPE html>
<html lang="en">
	<?php
	require_once($_SERVER['DOCUMENT_ROOT']."/includes/head.php");
	echo_head("Textube - Home", "style.css");
	?>
	
	<body>
		<div id="content">
			<div id="icon">
				<a href="/"><img src="/images/icon_32.png" /></a>
			</div>
			<div id="panel">
				<div id="name">
					<strong>Textube</strong>
				</div>
				<div id="motto">
					<strong>Communications, simplified.</strong>
				</div>
				<?php include("about.txt"); ?>
				
				<div id="download">
					<button onclick="window.location = 'download/download.php';">Download Textube</button>
				</div>
			</div>
		</div>
		<div id="footer">
			All rights reserved.<br />
			Questions? Contact nnifinn@gmail.com
		</div>
	</body>
</html>