<?php
require_once("base.php");

$root = $_SERVER['DOCUMENT_ROOT'];
$username = "textubeo_finn";
$password = "REDACTED";
$database = "textubeo_tb";
$uploads_table = "tb_uploads";

function build_file($uploaded_file = null, $file = null, $id = 0) {
	global $root, $username, $password, $database, $uploads_table;
	if ($id == 0) {
		$id = next_id();
	}
	$id_url = convert($id);
	if ($uploaded_file != null) {
		$file = $uploaded_file['tmp_name'];
	}
	$location = $file;
	$remote = $uploaded_file['name'];
	if (strpos($file, "/textu.be/_uploads/") === false) {
		$remoteinfo = pathinfo($remote);
		$extension = $remoteinfo['extension'];
		$location = "$root/textu.be/_uploads/$id_url.$extension";
		if ($id == 0) {
			move_uploaded_file($file, $location) or die("can't copy file");
		} else {
			copy($file, $location) or die("can't copy file");
		}
	}
	chmod($location, 0600);
	mysql_connect("localhost", $username, $password) or die("couldn't connect to mysql: ".mysql_error());
	mysql_select_db($database) or die("couldn't select database: ".mysql_error());
	$uploader_ip = get_ip();
	mysql_query("UPDATE $uploads_table SET id_url='$id_url', location='$location', filename='".($remote != null ? $remote : "Raw text")."', uploader_ip='$uploader_ip' WHERE id=$id");
	mysql_close();
	$dir = "$root/textu.be/$id_url";
	if (!file_exists($dir)) {
		mkdir($dir);
	}
	$dir_index = "$dir/index.php";
	$whandle = fopen($dir_index, "w") or die("can't open write file");
	$rhandle = fopen("$root/textu.be/base_index.txt", "r") or die("can't open read file");
	$pathinfo = pathinfo($location);
	$basename = $pathinfo['basename'];
	while (!feof($rhandle))  {
		$data = fgets($rhandle, 1024);
		$data = str_replace("_FILELOCATION_", $basename, $data);
		fwrite($whandle, $data);
	}
	fclose($rhandle);
	fclose($whandle);
	$public_url = str_replace("$root/", "http://", $dir);
	echo "success: $public_url";
}

function build_text($text) {
	global $root;
	$id = next_id();
	$id_url = convert($id);
	$filename = "$root/textu.be/_uploads/$id_url.txt";
	$handle = fopen($filename, "w") or die("can't open file");
	fwrite($handle, $text);
	fclose($handle);
	build_file(null, $filename, $id);
}

function next_id() {
	global $username, $password, $database, $uploads_table;
	mysql_connect("localhost", $username, $password) or die("can't connect to mysql: ".mysql_error());
	mysql_select_db($database) or die("can't select database: ". mysql_error());
	mysql_query("INSERT INTO $uploads_table() VALUES() ") or die("can't insert uploads row: ".mysql_error());
	$id = mysql_insert_id() or die("can't get id: ".mysql_error());
	mysql_close();
	return $id;
}

function get_ip() {
	if (getenv("HTTP_CLIENT_IP")) {
		$ip = getenv("HTTP_CLIENT_IP");
	} else if(getenv("HTTP_X_FORWARDED_FOR")) {
		$ip = getenv("HTTP_X_FORWARDED_FOR");
	} else if(getenv("REMOTE_ADDR")) {
		$ip = getenv("REMOTE_ADDR");
	} else {
		$ip = "UNKNOWN";
	}
	return $ip;
}

?>