<?php

function convert($number, $from_base = 10, $to_base = 62) {
    if ($to_base > 62 || $to_base < 2) {
        trigger_error("Invalid base (".he($to_base)."). Max base can be 62. Min base can be 2.", E_USER_ERROR);
    }
    if ("{$number}" === '0') {
        return 0;
    }
    if ($from_base == $to_base){
        return $number;
    }
    if ($from_base <= 36 && $to_base <= 36) {
        return base_convert($number, $from_base, $to_base);
    }
    $charlist = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if ($from_base < $to_base) {
        if ($from_base != 10){
            $decimal = self::convert($number, $from_base, 10);
        } else {
            $decimal = intval($number);
        }
        $charlist = substr($charlist, 0, $to_base);
        if ($number == 0) {
            return 0;
        }
        $converted = '';
        while ($number > 0) {
            $converted = $charlist{($number % $to_base)} . $converted;
            $number = floor($number / $to_base);
        }
        return $converted;
    } else {
        $number = "{$number}";
        $length = strlen($number);
        $decimal = 0;
        $i = 0;
        while ($length > 0) {
            $char = $number{$length-1};
            $pos = strpos($charlist, $char);
            if ($pos === false){
                trigger_error("Invalid character in the input number: ".($char), E_USER_ERROR);
            }
            $decimal += $pos * pow($from_base, $i);
            $length--;
            $i++;
        }
        return convert($decimal, 10, $to_base);
    }
}

?>