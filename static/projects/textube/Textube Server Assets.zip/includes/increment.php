<?php

function increment_download_count() {
	$path = $_SERVER['DOCUMENT_ROOT']."/download/";
	$version_path = $path."version.txt";
	$version_handle = fopen($version_path, "r");
	$line = fgets($version_handle);
	fclose($version_handle);
	$varr = explode(";", $line);
	$version = $varr[0];
	
	$log_path = $path."download_log.txt";
	$count = 0;
	if (file_exists($log_path)) {
		$contents = file_get_contents($log_path);
		$oldContents = $contents;
		$pos = strpos($contents, $version);
		if ($pos !== false) {
			$end_pos = strpos($contents, "\n", $pos);
			$sub = substr($contents, $pos, $end_pos - $pos);
			$larr = explode(":", $sub);
			$count = $larr[1];
			$new_sub = $sub;
			$new_sub = str_replace(":".$count, ":".($count + 1), $new_sub);
			$contents = str_replace($sub, $new_sub, $contents);
		} else {
			$contents .= $version.":".($count + 1)."\n";
		}
	} else {
		$contents = $version.":".($count + 1)."\n";
	}
	if (strlen($contents) >= strlen($oldContents)) {
		if ($handle = fopen($log_path, 'w')) {
			fclose($handle);
		}
		file_put_contents($log_path, $contents);
	} else {
		die("new contents invalid: ".$contents);
	}
}

?>