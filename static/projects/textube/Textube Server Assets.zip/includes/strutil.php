<?php

function insert_commas($var) {
	$str = strval($var);
	$len = strlen($str);
	if ($len < 4) {
		return $str;
	} else {
		return insert_commas(substr($str, 0, len - 3)).",".substr($str, len - 3);
	}
}

?>