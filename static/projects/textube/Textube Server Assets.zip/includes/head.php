<?php

function echo_head($title, $css_href = null) {
	echo "<head>
		<title>$title</title>
		<meta charset=\"utf-8\" />
		<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />
		<meta name=\"author\" content=\"Finn Thompson\" />
		<meta name=\"viewport\" content=\"width=device-width; initial-scale=1.0\" />
		<link rel=\"shortcut icon\" type=\"image/png\" href=\"/images/icon_16.png\" />
		<link rel=\"stylesheet\" type=\"text/css\" href=\"$css_href\">
	</head>";
}

?>