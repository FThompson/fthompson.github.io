package org.textube.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.textube.tools.Tool;
import org.textube.util.Configuration;
import org.textube.util.Database;
import org.textube.util.Resources;
import org.textube.util.Setting;

/**
 * Settings UI.
 */
public class SettingsFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * SettingsFrame constructor.
	 */
	public SettingsFrame() {
		initComponents();
	}

	/**
	 * Initializes settings UI components and layout.
	 */
	private void initComponents() {
		setTitle(Configuration.NAME + " - Settings");
		setIconImage(Resources.loadImage(Configuration.Paths.Resources.Images.COG));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		JPanel generalPanel = new JPanel();
		generalPanel.setLayout(new BoxLayout(generalPanel, BoxLayout.Y_AXIS));
		generalPanel.setBorder(BorderFactory.createTitledBorder("General"));
		for (Setting setting : Setting.getSettings()) {
			generalPanel.add(new SettingPanel(setting));
		}
		generalPanel.add(Box.createVerticalStrut(3));
		add(generalPanel);
		JPanel toolPanel = new JPanel();
		toolPanel.setLayout(new BoxLayout(toolPanel, BoxLayout.Y_AXIS));
		toolPanel.setBorder(BorderFactory.createTitledBorder("Tools"));
		for (Tool tool : Tool.getTools()) {
			toolPanel.add(new ToolPanel(tool));
			toolPanel.add(Box.createVerticalStrut(1));
		}
		toolPanel.add(Box.createVerticalStrut(2));
		add(toolPanel);
		add(Box.createVerticalStrut(3));
		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.X_AXIS));
		controlPanel.add(Box.createHorizontalGlue());
		JButton save = new JButton("Save");
		save.setFocusable(false);
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (Component child : getAllComponents(getContentPane())) {
					if (child instanceof DataEntry) {
						DataEntry data = (DataEntry) child;
						Database.setProperty(data.getDataKey(), data.getDataValue());
					}
				}
				Database.store();
				dispose();
			}
		});
		controlPanel.add(save);
		controlPanel.add(Box.createHorizontalStrut(2));
		JButton cancel = new JButton("Cancel");
		cancel.setFocusable(false);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		controlPanel.add(cancel);
		controlPanel.add(Box.createHorizontalStrut(3));
		add(controlPanel);
		add(Box.createVerticalStrut(3));
		pack();
		setLocationRelativeTo(null);
	}
	
	/**
	 * Gets all components of the JFrame.
	 */
	public Component[] getAllComponents() {
		List<Component> components = getAllComponents(getContentPane());
		return components.toArray(new Component[components.size()]);
	}

	/**
	 * Recursively gets all components in a container.
	 */
	private static List<Component> getAllComponents(final Container container) {
		List<Component> components = new ArrayList<Component>();
		for (Component comp : container.getComponents()) {
			components.add(comp);
			if (comp instanceof Container) {
				components.addAll(getAllComponents((Container) comp));
			}
		}
		return components;
	}

	/**
	 * Setting check box panel.
	 */
	private static class SettingPanel extends JPanel implements DataEntry {

		private Setting setting = null;
		private JCheckBox checkBox = null;
		private static final long serialVersionUID = 1L;

		/**
		 * SettingPanel constructor.
		 */
		public SettingPanel(Setting setting) {
			this.setting = setting;
			initComponents();
		}

		/**
		 * Gets the setting data key.
		 */
		@Override
		public String getDataKey() {
			return setting.getDataKey();
		}

		/**
		 * Gets the setting panel data value.
		 */
		@Override
		public String getDataValue() {
			return Boolean.toString(checkBox.isSelected());
		}

		/**
		 * Initializes setting panel components and layout.
		 */
		private void initComponents() {
			setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
			checkBox = new JCheckBox(setting.getName(), setting.getValue());
			checkBox.setFocusable(false);
			add(Box.createHorizontalGlue());
			add(checkBox);
			add(Box.createHorizontalGlue());
		}

	}

	/**
	 * Tool keyhook settings panel.
	 */
	private static class ToolPanel extends JPanel implements DataEntry {

		private int keyCode = 0;
		private Tool tool = null;
		private JTextField key = null;
		private static List<ToolPanel> toolPanels = new ArrayList<ToolPanel>();
		private static final long serialVersionUID = 1L;

		/**
		 * ToolPanel constructor.
		 */
		public ToolPanel(Tool tool) {
			this.tool = tool;
			keyCode = tool.getKey();
			toolPanels.add(this);
			initComponents();
		}

		/**
		 * Gets the tool data key.
		 */
		@Override
		public String getDataKey() {
			return tool.getDataKey();
		}

		/**
		 * Gets the tool panel data value.
		 */
		@Override
		public String getDataValue() {
			return Integer.toString(keyCode);
		}

		/**
		 * Initializes tool panel components and layout.
		 */
		private void initComponents() {
			setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
			JLabel toolLabel = new JLabel(tool.getToolName());
			add(Box.createHorizontalStrut(3));
			add(toolLabel);
			add(Box.createHorizontalStrut(20));
			JPanel eastPanel = new JPanel();
			eastPanel.setLayout(new BorderLayout());
			String tooltip = "Press a key to map it to the tool";
			JLabel ctrlShift = new JLabel("Ctrl+Shift+");
			ctrlShift.setToolTipText(tooltip);
			ctrlShift.addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					key.requestFocus();
				}
			});
			eastPanel.add(ctrlShift, BorderLayout.WEST);
			key = new JTextField(2);
			key.setToolTipText(tooltip);
			key.setEditable(false);
			key.setHorizontalAlignment(JTextField.CENTER);
			key.setText(KeyEvent.getKeyText(keyCode));
			key.addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent e) {
					int code = e.getKeyCode();
					if (!isInUse(code) && ((code >= KeyEvent.VK_0 && code <= KeyEvent.VK_9)
							|| (code >= KeyEvent.VK_A && code <= KeyEvent.VK_Z)
							|| (code >= KeyEvent.VK_F1 && code <= KeyEvent.VK_F12)
							|| (code >= KeyEvent.VK_F13 && code <= KeyEvent.VK_F19))) {
						keyCode = code;
						key.setText(KeyEvent.getKeyText(e.getKeyCode()));
					}
				}
			});
			key.addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					key.requestFocus();
				}
			});
			eastPanel.add(key, BorderLayout.EAST);
			add(eastPanel);
			add(Box.createHorizontalStrut(3));
		}
		
		/**
		 * Checks if another tool panel has the keycode already.
		 */
		private boolean isInUse(int keyCode) {
			for (ToolPanel toolPanel : toolPanels) {
				if (!this.equals(toolPanel)) {
					if (keyCode == toolPanel.keyCode) {
						return true;
					}
				}
			}
			return false;
		}
	}

	/**
	 * Interface for an object which should be saved into database settings.
	 */
	private interface DataEntry {

		/**
		 * Data key.
		 */
		public String getDataKey();

		/**
		 * Data value.
		 */
		public String getDataValue();

	}

}
