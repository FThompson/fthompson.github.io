package org.textube.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;

import org.textube.Textube;
import org.textube.util.ClipboardUtil;
import org.textube.util.Configuration;
import org.textube.util.Internet;
import org.textube.util.PostProcess;
import org.textube.util.Resources;
import org.textube.util.Setting;

/**
 * Upload process progress display UI.
 */
public class ProcessDisplay extends JDialog implements Runnable {
	
	private boolean running = false;
	private PostProcess process = null;
	private JProgressBar progressBar = null;
	private static final int DIALOG_WIDTH = 227;
	private static final int DIALOG_HEIGHT = 70;
	private static final long serialVersionUID = 1L;
	
	/**
	 * ProcessDisplay constructor.
	 */
	public ProcessDisplay(PostProcess process) {
		this.process = process;
		initComponents();
	}

	/**
	 * Updates the display while process is running, and handles process completion.
	 */
	public void run() {
		running = true;
		while (running) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					progressBar.setValue((int) Math.ceil(ProcessDisplay.this.process.getProgress()));
				}
			});
			if (ProcessDisplay.this.process.isComplete()) {
				String response = ProcessDisplay.this.process.getResponse();
				if (response != null && response.startsWith("success: ")) {
					response = response.replace("success: ", "");
					if (Setting.getValue("Tray message on success")) {
						Textube.getTray().displayMessage(Configuration.NAME, response, TrayIcon.MessageType.INFO);
					}
					if (Setting.getValue("Play audio on success")) {
						Resources.playClip(Configuration.Paths.Resources.Audio.SUCCESS);
					}
					if (Setting.getValue("Set links to clipboard")) {
						ClipboardUtil.setContents(response);
					}
					if (Setting.getValue("Open links on success")) {
						try {
							Internet.openWebpage(new URI(response));
						} catch (URISyntaxException e) {
							e.printStackTrace();
						}
					}
				} else {
					Textube.getTray().displayMessage(Configuration.NAME, "Upload failed.", TrayIcon.MessageType.ERROR);
					Toolkit.getDefaultToolkit().beep();
				}
				if (!hasFocus()) {
					dispose();
				}
				break;
			}
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
			}
		}
	}
	
	/**
	 * Initializes process display UI components and layout.
	 */
	private void initComponents() {
		String title = null;
		if (ProcessDisplay.this.process.getFile() != null) {
			title = ProcessDisplay.this.process.getFile().getName();
		} else {
			title = ProcessDisplay.this.process.getParameters().get("text");
		}
		setTitle(title);
		setResizable(false);
		Dimension size = new Dimension(DIALOG_WIDTH, DIALOG_HEIGHT);
		setSize(size);
		setPreferredSize(size);
		Rectangle screen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
		setLocation(screen.width - size.width - 6, screen.height - size.height - 6);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				running = false;
			}
		});
		addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				if (process.isComplete()) {
					dispose();
				}
			}
		});
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		setContentPane(panel);
		progressBar = new JProgressBar(0, 100);
		progressBar.setStringPainted(true);
		Dimension barSize = new Dimension(150, 50);
		progressBar.setSize(barSize);
		progressBar.setPreferredSize(barSize);
		panel.add(progressBar, BorderLayout.WEST);
		JButton cancel = new JButton("Cancel");
		cancel.setFocusable(false);
		Dimension cancelSize = new Dimension(70, 50);
		cancel.setSize(cancelSize);
		cancel.setPreferredSize(cancelSize);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				process.interrupt();
				dispose();
			}
		});
		panel.add(cancel, BorderLayout.EAST);
		pack();
	}

}
