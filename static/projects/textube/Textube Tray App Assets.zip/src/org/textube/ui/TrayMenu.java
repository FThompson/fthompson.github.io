package org.textube.ui;

import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.textube.Textube;
import org.textube.tools.Tool;
import org.textube.util.Configuration;

/**
 * Tray popup menu UI.
 */
public class TrayMenu extends PopupMenu {

	private static final long serialVersionUID = 1L;
	
	/**
	 * TrayMenu constructor.
	 */
	public TrayMenu() {
		initItems();
	}
	
	/**
	 * Initializes tray menu items.
	 */
	private void initItems() {
		MenuItem title = new MenuItem(Configuration.NAME + " v" + Configuration.getVersion());
		title.setEnabled(false);
		add(title);
		addSeparator();
		for (final Tool tool : Tool.getTools()) {
			createMenuItem(tool.getToolName(), new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tool.perform();
				}
			});
		}
		addSeparator();
		createMenuItem("Settings...", new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SettingsFrame settings = new SettingsFrame();
				settings.setVisible(true);
			}
		});
		addSeparator();
		createMenuItem("Exit", new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Textube.exit(0);
			}
		});
	}
	
	/**
	 * Creates a menu item.
	 */
	private void createMenuItem(String label, ActionListener listener) {
		MenuItem item = new MenuItem(label);
		item.addActionListener(listener);
		add(item);
	}

}
