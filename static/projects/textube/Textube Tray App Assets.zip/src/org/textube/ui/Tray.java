package org.textube.ui;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.net.URISyntaxException;

import org.textube.util.Configuration;
import org.textube.util.Internet;
import org.textube.util.Resources;

/**
 * Tray handler.
 */
public class Tray {
	
	private String lastMessage = null;
	private TrayIcon icon = null;
	private TrayMenu menu = null;
	private SystemTray tray = null;
	
	/**
	 * Initializes tray and its UI.
	 */
	public void initialize() {
		tray = SystemTray.getSystemTray();
		menu = new TrayMenu();
		Image iconImage = null;
		Dimension traySize = tray.getTrayIconSize();
		if (traySize.width < 32 && traySize.height < 32) {
			iconImage = Resources.loadImage(Configuration.Paths.Resources.Images.ICON_16);
		} else {
			iconImage = Resources.loadImage(Configuration.Paths.Resources.Images.ICON_32);
		}
		icon = new TrayIcon(iconImage, Configuration.NAME + " v" + Configuration.getVersion(), menu);
		icon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (lastMessage != null) {
					URI uri = null;
					try {
						uri = new URI(lastMessage);
					} catch (URISyntaxException ex) {
					}
					if (uri != null) {
						Internet.openWebpage(uri);
					}
				}
			}
		});
		try {
			tray.add(icon);
		} catch (AWTException e) {
			e.printStackTrace();
			System.out.println("Failed to add tray icon.");
		}
	}
	
	/**
	 * Displays a tray message.
	 */
	public void displayMessage(String caption, String text, TrayIcon.MessageType messageType) {
		icon.displayMessage(caption, text, messageType != null ? messageType : MessageType.NONE);
		lastMessage = text;
	}
	
	/**
	 * Removes the tray icon.
	 */
	public void remove() {
		tray.remove(icon);
	}

}
