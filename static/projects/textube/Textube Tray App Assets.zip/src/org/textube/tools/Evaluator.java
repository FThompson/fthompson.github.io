package org.textube.tools;

import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.textube.Textube;
import org.textube.util.ClipboardUtil;
import org.textube.util.Configuration;
import org.textube.util.Resources;
import org.textube.util.Setting;

/**
 * Basic clipboard mathematical expression evaluator tool.
 */
public class Evaluator extends Tool {
	
	private static final Pattern EXPRESSION = Pattern.compile("(-?[\\d\\.]*)([\\+\\-\\*/\\^])(-?[\\d\\.]*)([=><])?((-?[\\d\\.]*))?");
	
	/**
	 * Evaluates the clipboard.
	 */
	@Override
	public void run() {
		Object clipboard = ClipboardUtil.getContents();
		if (clipboard != null) {
			if (clipboard instanceof String) {
				String text = (String) clipboard;
				if (text.equals("info")) {
					StringBuilder info = new StringBuilder();
					info.append("Operators: ");
					for (Operation operation : Operation.getOperations()) {
						info.append(operation.getOperator());
					}
					info.append("\n");
					info.append("Evaluators: ");
					for (Evaluation evaluation : Evaluation.getEvaluations()) {
						info.append(evaluation.getEvaluator());
					}
					String response = info.toString();
					if (Setting.getValue("Tray message on success")) {
						Textube.getTray().displayMessage(Configuration.NAME, response, TrayIcon.MessageType.INFO);
					}
					if (Setting.getValue("Play audio on success")) {
						Resources.playClip(Configuration.Paths.Resources.Audio.SUCCESS);
					}
					if (Setting.getValue("Set links to clipboard")) {
						ClipboardUtil.setContents(response);
					}
				} else {
					text = text.replace(" ", "");
					Matcher matcher = EXPRESSION.matcher(text);
					if (matcher.find()) {
						double a = Double.parseDouble(matcher.group(1));
						Operation operation = Operation.getOperation(matcher.group(2));
						double b = Double.parseDouble(matcher.group(3));
						String group4 = matcher.group(4);
						Evaluation evaluator = group4 != null && !group4.isEmpty() ? Evaluation.getEvaluation(group4) : null;
						String group5 = matcher.group(5);
						Double right = group5 != null && !group5.isEmpty() ? Double.parseDouble(group5) : null;
						double left = operation.operate(a, b);
						if (evaluator != null && right != null) {
							boolean result = evaluator.evaluate(left, right);
							String response = Boolean.toString(result);
							if (Setting.getValue("Tray message on success")) {
								Textube.getTray().displayMessage(Configuration.NAME, response, TrayIcon.MessageType.INFO);
							}
							if (Setting.getValue("Play audio on success")) {
								Resources.playClip(Configuration.Paths.Resources.Audio.SUCCESS);
							}
							if (Setting.getValue("Set links to clipboard")) {
								ClipboardUtil.setContents(response);
							}
						} else {
							String response = Double.toString(left);
							if (Setting.getValue("Tray message on success")) {
								Textube.getTray().displayMessage(Configuration.NAME, response, TrayIcon.MessageType.INFO);
							}
							if (Setting.getValue("Play audio on success")) {
								Resources.playClip(Configuration.Paths.Resources.Audio.SUCCESS);
							}
							if (Setting.getValue("Set links to clipboard")) {
								ClipboardUtil.setContents(response);
							}
						}
					} else {
						Toolkit.getDefaultToolkit().beep();
					}
				}
			} else {
				Toolkit.getDefaultToolkit().beep();
			}
		}
	}

	/**
	 * Gets the tool name.
	 */
	@Override
	public String getToolName() {
		return "Evaluate Clipboard";
	}

	/**
	 * Gets the default keyhook key.
	 */
	@Override
	public int getDefaultKey() {
		return KeyEvent.VK_E;
	}
	
	/**
	 * Abstract mathematical operation class.
	 */
	private static abstract class Operation {
		
		private static List<Operation> operations = new ArrayList<Operation>();
		
		/**
		 * Operates upon two values.
		 */
		public abstract double operate(double a, double b);
		
		/**
		 * Gets the operator string.
		 */
		public abstract String getOperator();
		
		/**
		 * Gets all supported operations.
		 */
		public static Operation[] getOperations() {
			return operations.toArray(new Operation[operations.size()]);
		}
		
		/**
		 * Gets the operation of the given operator.
		 */
		public static Operation getOperation(String operator) {
			for (Operation operation : operations) {
				if (operator.equals(operation.getOperator())) {
					return operation;
				}
			}
			return null;
		}
		
		static {
			operations.add(new Addition());
			operations.add(new Subtraction());
			operations.add(new Multiplication());
			operations.add(new Division());
			operations.add(new Power());
		}
		
	}
	
	/**
	 * Addition operation.
	 */
	private static class Addition extends Operation {

		/**
		 * Adds two doubles.
		 */
		@Override
		public double operate(double a, double b) {
			return a + b;
		}

		/**
		 * Gets the operator string.
		 */
		@Override
		public String getOperator() {
			return "+";
		}
		
	}
	
	/**
	 * Subtraction operation.
	 */
	private static class Subtraction extends Operation {

		/**
		 * Subtracts one double from another.
		 */
		@Override
		public double operate(double a, double b) {
			return a - b;
		}

		/**
		 * Gets the operator string.
		 */
		@Override
		public String getOperator() {
			return "-";
		}
	
	}
	
	/**
	 * Multiplication operation.
	 */
	private static class Multiplication extends Operation {

		/**
		 * Multiplies two doubles.
		 */
		@Override
		public double operate(double a, double b) {
			return a * b;
		}

		/**
		 * Gets the operator string.
		 */
		@Override
		public String getOperator() {
			return "*";
		}
		
	}
	
	/**
	 * Division operation.
	 */
	private static class Division extends Operation {

		/**
		 * Divides one double by another.
		 */
		@Override
		public double operate(double a, double b) {
			return a / b;
		}

		/**
		 * Gets the operator string.
		 */
		@Override
		public String getOperator() {
			return "/";
		}
		
	}
	
	/**
	 * Power operation.
	 */
	private static class Power extends Operation {

		/**
		 * Puts a double to a power.
		 */
		@Override
		public double operate(double a, double b) {
			return Math.pow(a, b);
		}

		/**
		 * Gets the operator string.
		 */
		@Override
		public String getOperator() {
			return "^";
		}
		
	}
	
	/**
	 * Abstract mathematical evaluation class.
	 */
	private static abstract class Evaluation {
		
		private static List<Evaluation> evaluations = new ArrayList<Evaluation>();
		
		/**
		 * Evaluates two values.
		 */
		public abstract boolean evaluate(double a, double b);
		
		/**
		 * Gets the evaluator string.
		 */
		public abstract String getEvaluator();
		
		/**
		 * Gets all supported evaluations.
		 */
		public static Evaluation[] getEvaluations() {
			return evaluations.toArray(new Evaluation[evaluations.size()]);
		}
		
		/**
		 * Gets the evaluation of the given evaluator.
		 */
		public static Evaluation getEvaluation(String evaluator) {
			for (Evaluation evaluation : evaluations) {
				if (evaluator.equals(evaluation.getEvaluator())) {
					return evaluation;
				}
			}
			return null;
		}
		
		static {
			evaluations.add(new Equality());
			evaluations.add(new GreaterThan());
			evaluations.add(new LessThan());
		}
		
	}
	
	/**
	 * Equality evaluation.
	 */
	private static class Equality extends Evaluation {

		/**
		 * Evaluates equality between two doubles.
		 */
		@Override
		public boolean evaluate(double a, double b) {
			return a == b;
		}

		/**
		 * Gets the evaluator string.
		 */
		@Override
		public String getEvaluator() {
			return "=";
		}
		
	}
	
	/**
	 * Greater than evaluation.
	 */
	private static class GreaterThan extends Evaluation {

		/**
		 * Evaluates greater-than between two doubles.
		 */
		@Override
		public boolean evaluate(double a, double b) {
			return a > b;
		}

		/**
		 * Gets the evaluator string.
		 */
		@Override
		public String getEvaluator() {
			return ">";
		}
		
	}
	
	/**
	 * Less than evaluation.
	 */
	private static class LessThan extends Evaluation {

		/**
		 * Evaluates less-than between two doubles.
		 */
		@Override
		public boolean evaluate(double a, double b) {
			return a < b;
		}

		/**
		 * Gets the evaluator string.
		 */
		@Override
		public String getEvaluator() {
			return "<";
		}
		
	}

}
