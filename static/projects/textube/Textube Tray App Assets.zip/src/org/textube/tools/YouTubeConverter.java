package org.textube.tools;

public class YouTubeConverter extends Tool {

	@Override
	public void run() {
		// TODO Auto-generated method stub
	}

	@Override
	public String getToolName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDefaultKey() {
		// TODO Auto-generated method stub
		return 0;
	}

}
