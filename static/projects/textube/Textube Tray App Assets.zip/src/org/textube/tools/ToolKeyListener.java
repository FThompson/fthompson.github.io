package org.textube.tools;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import org.textube.util.Setting;

/**
 * Handles keys and runs tools if tool key combos are pressed.
 */
public class ToolKeyListener extends KeyAdapter {
	
	/**
	 * Handles pressed keys.
	 */
	public void keyPressed(KeyEvent e) {
		if (Setting.getValue("Tool hotkeys enabled")) {
			int onmask = KeyEvent.CTRL_DOWN_MASK | KeyEvent.SHIFT_DOWN_MASK;
			int offmask = KeyEvent.ALT_DOWN_MASK;
			if ((e.getModifiersEx() & (onmask | offmask)) == onmask) {
				for (final Tool tool : Tool.getTools()) {
					if (tool.getKey() == e.getKeyCode()) {
						tool.perform();
					}
				}
			}
		}
	}
	
}
