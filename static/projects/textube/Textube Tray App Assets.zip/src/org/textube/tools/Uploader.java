package org.textube.tools;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.HashMap;
import java.util.List;

import javax.swing.SwingUtilities;

import org.textube.ui.ProcessDisplay;
import org.textube.util.ClipboardUtil;
import org.textube.util.Configuration;
import org.textube.util.PostProcess;

/**
 * Clipboard uploader tool.
 */
public class Uploader extends Tool {

	/**
	 * Uploads the clipboard to remote server.
	 */
	@Override
	public void run() {
		Object clipboard = ClipboardUtil.getContents();
		if (clipboard != null) {
			if (clipboard instanceof String) {
				String text = (String) clipboard;
				HashMap<String, String> params = new HashMap<String, String>();
				params.put("text", text);
				final PostProcess process = new PostProcess(Configuration.Paths.Resources.URLs.UPLOAD, params, null);
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						ProcessDisplay display = new ProcessDisplay(process);
						display.setVisible(true);
						Thread displayUpdater = new Thread(display);
						displayUpdater.setPriority(Thread.MIN_PRIORITY);
						displayUpdater.start();
					}
				});
				process.start();
			} else {
				List<File> files = (List<File>) clipboard;
				if (files.size() > 0) {
					File file = files.get(0);
					final PostProcess process = new PostProcess(Configuration.Paths.Resources.URLs.UPLOAD, null, file);
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							ProcessDisplay display = new ProcessDisplay(process);
							display.setVisible(true);
							display.toFront();
							Thread displayUpdater = new Thread(display);
							displayUpdater.setPriority(Thread.MIN_PRIORITY);
							displayUpdater.start();
						}
					});
					process.start();
				}
			}
		} else {
			Toolkit.getDefaultToolkit().beep();
		}
	}

	/**
	 * Gets the tool name.
	 */
	@Override
	public String getToolName() {
		return "Upload Clipboard";
	}

	/**
	 * Gets the default keyhook key.
	 */
	@Override
	public int getDefaultKey() {
		return KeyEvent.VK_V;
	}

}
