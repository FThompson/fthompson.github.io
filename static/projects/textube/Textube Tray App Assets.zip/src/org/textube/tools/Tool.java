package org.textube.tools;

import java.util.ArrayList;
import java.util.List;

import org.textube.util.Database;

/**
 * Abstract tool class for background utilities.
 */
public abstract class Tool implements Runnable {
	
	private static List<Tool> tools = new ArrayList<Tool>();
	
	/**
	 * Runs the tool.
	 */
	public abstract void run();
	
	/**
	 * Gets the tool name.
	 */
	public abstract String getToolName();
	
	/**
	 * Gets the default keyhook key.
	 */
	public abstract int getDefaultKey();
	
	/**
	 * Asynchronously runs the tool.
	 */
	public final void perform() {
		Thread tool = new Thread(this);
		tool.start();
	}
	
	/**
	 * Gets the database keyhook key, or the default if none stored.
	 */
	public final int getKey() {
		String keycombo = Database.getProperty(getDataKey());
		if (keycombo != null) {
			return Integer.parseInt(keycombo);
		}
		return getDefaultKey();
	}
	
	/**
	 * Gets the database property key.
	 */
	public final String getDataKey() {
		return getToolName().toLowerCase().replace(" ", "_") + "_key";
	}
	
	/**
	 * Gets all installed tools.
	 */
	public static Tool[] getTools() {
		return tools.toArray(new Tool[tools.size()]);
	}
	
	static {
		tools.add(new Uploader());
		tools.add(new Evaluator());
	}

}
