package org.textube.util;

import java.awt.Desktop;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;

/**
 * Internet-related utilities.
 */
public class Internet {
	
	private static String httpUserAgent = null;

	/**
	 * Connects to a url and downloads the bytes offered.
	 */
	public static byte[] downloadBinary(URL url) throws IOException {
		return downloadBinary(getConnection(url));
	}

	/**
	 * Downloads the bytes offered by a given url connection.
	 */
	private static byte[] downloadBinary(URLConnection uc) throws IOException {
		int len = uc.getContentLength();
		InputStream is = new BufferedInputStream(uc.getInputStream());
		try {
			byte[] data = new byte[len];
			int offset = 0;
			int updateCounter = 0;
			while (offset < len) {
				int read = is.read(data, offset, data.length - offset);
				if (read < 0) {
					break;
				}
				updateCounter += read;
				offset += read;
				if (updateCounter > 32) {
					updateCounter = 0;
				}
			}
			if (offset < len) {
				throw new IOException(String.format("Read %d bytes; expected %d", offset, len));
			}
			return data;
		} finally {
			is.close();
		}
	}

	/**
	 * Connects to a url and downloads the bytes offered as a string.
	 */
	public static String downloadAsString(URL url) throws IOException {
		return downloadAsString(url.openConnection());
	}

	/**
	 * Downloads the bytes offered, as a string, by a given url connection.
	 */
	public static String downloadAsString(URLConnection con) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF8"));
		String string = "";
		String output;
		while ((output = in.readLine()) != null) {
			string += output;
		}
		in.close();
		return string;
	}
	
	/**
	 * Connects to a url and downloads the bytes to a file.
	 */
	public static boolean downloadAndSaveFile(URL url, File file) throws IOException {
		return downloadAndSaveFile(url.openConnection(), file);
	}

	/**
	 * Downloads the bytes offered, to a file, by a given url connection.
	 */
	public static boolean downloadAndSaveFile(URLConnection con, File file) throws IOException {
		int len = con.getContentLength();
		InputStream reader = con.getInputStream();
		FileOutputStream writer = new FileOutputStream(file);
		byte[] buffer = new byte[153600];
		int totalBytesRead = 0;
		int bytesRead = 0;
		while ((bytesRead = reader.read(buffer)) > 0) {  
			writer.write(buffer, 0, bytesRead);
			buffer = new byte[153600];
			totalBytesRead += bytesRead;
		}
		writer.close();
		reader.close();
		return totalBytesRead == len;
	}

	/**
	 * Gets the default http user agent.
	 */
	private static String getDefaultHttpUserAgent() {
		boolean x64 = System.getProperty("sun.arch.data.model").equals("64");
		String os;
		switch (Configuration.getOS()) {
		case MAC:
			os = "Macintosh; Intel Mac OS X 10_6_6";
			break;
		case LINUX:
			os = "X11; Linux " + (x64 ? "x86_64" : "i686");
			break;
		default:
			os = "Windows NT 6.1" + (x64 ? "; WOW64" : "");
			break;
		}
		StringBuilder buf = new StringBuilder(125);
		buf.append("Mozilla/5.0 (").append(os).append(")");
		buf.append(" AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.100 Safari/534.30");
		return buf.toString();
	}

	/**
	 * Gets an http connection to a given url.
	 */
	public static HttpURLConnection getConnection(URL url) throws IOException {
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		con.addRequestProperty("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
		con.addRequestProperty("Accept-Encoding", "gzip");
		con.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
		con.addRequestProperty("Host", url.getHost());
		con.addRequestProperty("User-Agent", getHttpUserAgent());
		con.setConnectTimeout(10000);
		con.setUseCaches(true);
		return con;
	}

	/**
	 * Gets the http user agent.
	 */
	public static String getHttpUserAgent() {
		if (httpUserAgent == null) {
			httpUserAgent = getDefaultHttpUserAgent();
		}
		return httpUserAgent;
	}
	
	/**
	 * Opens a url in the default browser.
	 */
	public static void openWebpage(URI uri) {
		Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
		if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
			try {
				desktop.browse(uri);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
