package org.textube.util;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 * Classpath resource handler.
 */
public class Resources {
	
	private static String dir = "/";
	
	/**
	 * Loads an image.
	 */
	public static BufferedImage loadImage(final String name) {
		InputStream in = Resources.class.getResourceAsStream(dir + name);
		try {
			return ImageIO.read(in);
		} catch (Exception e) {
			System.out.println("Failed to load image: " + name);
		} finally {
			try {
				in.close();
			} catch (IOException e) {
			}
		}
		return null;
	}
	
	/**
	 * Plays an audio clip.
	 */
	public static void playClip(String name) {
		AudioInputStream in = null;
		try {
			in = AudioSystem.getAudioInputStream(Resources.class.getResourceAsStream(dir + name));
			Clip clip = AudioSystem.getClip();
			clip.open(in);
			clip.start();
		} catch (Exception e) {
			System.out.println("failed to play clip: " + name);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
		}
	}
	
	/**
	 * Sets the default resource directory.
	 */
	public static void setDirectory(String dir) {
		Resources.dir = (!dir.startsWith("/") ? "/" : "") + dir;
	}

	/**
	 * Gets the default resource directory.
	 */
	public static String getDirectory() {
		return dir;
	}
}