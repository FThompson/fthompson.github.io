package org.textube.util;

import java.io.File;
import java.io.IOException;

/**
 * File explorer utilities.
 */
public class FileExplorer {

	/**
	 * Reveals a file in a file explorer.
	 */
	public static void reveal(File file) throws IOException {
		reveal(file.getAbsolutePath());
	}

	/**
	 * Reveals a file in a file explorer.
	 */
	public static void reveal(String file) throws IOException {
		boolean sh = true;
		char q = '"', s = ' ';
		StringBuilder param = new StringBuilder(64);
		switch (Configuration.getOS()) {
		case WINDOWS:
			sh = false;
			param.append("Explorer /select,");
			break;
		case MAC:
			param.append("open -R");
			break;
		case LINUX:
			param.append("xdg-open");
			break;
		default:
			return;
		}
		param.append(s);
		param.append(q);
		param.append(file);
		param.append(q);
		Runtime run = Runtime.getRuntime();
		if (sh) {
			run.exec(new String[]{"/bin/sh", "-c", param.toString()});
		} else {
			run.exec(param.toString());
		}
	}

}
