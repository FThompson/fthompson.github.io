package org.textube.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Application setting flag.
 */
public class Setting {
	
	private String name = null;
	private boolean defaultValue = false;
	private static List<Setting> settings = new ArrayList<Setting>();
	
	/**
	 * Setting constructor.
	 */
	private Setting(String name, boolean defaultValue) {
		this.name = name;
		this.defaultValue = defaultValue;
	}
	
	/**
	 * Gets the setting name.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Gets the default setting value.
	 */
	public boolean getDefaultValue() {
		return defaultValue;
	}
	
	/**
	 * Gets the database setting value, or the default if none stored.
	 */
	public boolean getValue() {
		String value = Database.getProperty(getDataKey());
		if (value != null) {
			return Boolean.parseBoolean(value);
		}
		return getDefaultValue();
	}
	
	/**
	 * Gets the database property key.
	 */
	public String getDataKey() {
		return name.toLowerCase().replace(" ", "_");
	}
	
	/**
	 * Gets the value of the setting of given name.
	 */
	public static boolean getValue(String name) {
		for (Setting setting : settings) {
			if (setting.getName().equals(name)) {
				return setting.getValue();
			}
		}
		throw new NullPointerException("no setting of name \"" + name + "\"");
	}
	
	/**
	 * Gets all settings.
	 */
	public static Setting[] getSettings() {
		return settings.toArray(new Setting[settings.size()]);
	}
	
	static {
		settings.add(new Setting("Set links to clipboard", true));
		settings.add(new Setting("Play audio on success", true));
		settings.add(new Setting("Tray message on success", true));
		settings.add(new Setting("Open links on success", false));
		settings.add(new Setting("Tool hotkeys enabled", true));
	}

}
