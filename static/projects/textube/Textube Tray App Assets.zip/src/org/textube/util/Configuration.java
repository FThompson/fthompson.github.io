package org.textube.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.URL;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;

import org.textube.Textube;

/**
 * Application configuration.
 */
public class Configuration {
	
	/**
	 * Operating system representation.
	 */
	public static enum OS {
		WINDOWS("Windows"),
		MAC("Mac"),
		LINUX("Linux"),
		UNKNOWN("");
		
		private String name;
		
		private OS(String name) {
			this.name = name;
		}
		
		/**
		 * Gets operating system short name.
		 */
		public String getName() {
			return name;
		}
	}
	
	/**
	 * Configuration paths.
	 */
	public static class Paths {
		
		/**
		 * Configuration resource paths.
		 */
		public static interface Resources {

			public static final String ROOT = "resources";
			
			/**
			 * Configuration image resource paths.
			 */
			public static interface Images {
				
				public static final String ROOT = Resources.ROOT + "/images";
				public static final String ICON_32 = ROOT + "/icon_32.png";
				public static final String ICON_16 = ROOT + "/icon_16.png";
				public static final String COG = ROOT + "/cog.png";
			}

			/**
			 * Configuration audio resource paths.
			 */
			public static interface Audio {
				
				public static final String ROOT = Resources.ROOT + "/audio";
				public static final String SUCCESS = ROOT + "/success.wav";
			}
			
			/**
			 * Configuration external library paths.
			 */
			public static interface Libraries {
				
				public static final String ROOT = "/Lib";
				public static final String TRIDENT = ROOT + "/trident.jar";
				public static final String SUBSTANCE = ROOT + "/substance.jar";
				public static final String JNA = ROOT + "/jna.jar";
				public static final String PLATFORM = ROOT + "/platform.jar";
				public static final String[] LIBRARIES =  { SUBSTANCE, TRIDENT, JNA, PLATFORM };
			}

			/**
			 * Configuration resource URLs.
			 */
			public static interface URLs {
				
				public static final String HOME = "http://textube.org";
				public static final String SHORT = "http://textu.be";
				public static final String UPLOAD = HOME + "/upload.php";
				public static final String DOWNLOAD = HOME + "/download/download.php";
				public static final String VERSION = HOME + "/download/version.txt";

				/**
				 * Configuration external library URLs.
				 */
				public static interface Libraries {
					
					public static final String BASE = HOME + "/resources";
					public static final String TRIDENT = BASE + "/trident.jar";
					public static final String SUBSTANCE = BASE + "/substance.jar";
					public static final String JNA = BASE + "/jna.jar";
					public static final String PLATFORM = BASE + "/platform.jar";
					public static final String[] LIBRARIES =  { SUBSTANCE, TRIDENT, JNA, PLATFORM };
				}
			}
		}
		
		/**
		 * Gets the documents home directory location.
		 */
		public static String getHomeDirectory() {
			final String env = System.getenv(NAME.toUpperCase() + "_HOME");
			if (env != null && !env.isEmpty()) {
				return env;
			} else {
				final String home;
				if (os.equals(OS.WINDOWS)) {
					home = FileSystemView.getFileSystemView().getDefaultDirectory().getAbsolutePath();
				} else {
					home = getUnixHome();
				}
				return home + File.separator + NAME;
			}
		}
		
		/**
		 * Gets the home Lib directory location.
		 */
		public static String getLibDirectory() {
			return getHomeDirectory() + File.separator + "Lib";
		}
		
		/**
		 * Gets database file location.
		 */
		public static String getDatabaseFile() {
			String path = null;
			if (getOS().equals(OS.WINDOWS)) {
				path = System.getenv("APPDATA") + File.separator + Configuration.NAME + ".db";
			} else {
				path = getUnixHome() + File.separator + "." + NAME.toLowerCase() + "data";
			}
			return path;
		}
		
		/**
		 * Gets unix home location.
		 */
		public static String getUnixHome() {
			String home = System.getProperty("user.home");
			return home != null ? home : "~";
		}
		
		/**
		 * Gets all external library locations.
		 */
		public static String[] getLibraryPaths() {
			final String[] paths = new String[Resources.Libraries.LIBRARIES.length];
			final String base = getHomeDirectory();
			int i = 0;
			for (final String lib : Resources.Libraries.LIBRARIES) {
				paths[i++] = base + lib;
			}
			return paths;
		}
	}
	
	private static OS os = null;
	public static boolean update = false;
	public static boolean updateChecked = false;
	public static final String NAME = "Textube";
	public static final int MAJOR_VERSION = 1;
	public static final double MINOR_VERSION = 0.0;
	
	/**
	 * Gets operating system.
	 */
	public static OS getOS() {
		return os;
	}
	
	/**
	 * Gets application version.
	 */
	public static String getVersion() {
		return MAJOR_VERSION + "." + MINOR_VERSION;
	}
	
	/**
	 * Checks for updates and offers to update automatically.
	 */
	public static void applyUpdates() {
		String versionFile;
		try {
			versionFile = Internet.downloadAsString(new URL(Paths.Resources.URLs.VERSION));
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		String[] contents = versionFile.split(";");
		String version = contents[0];
		boolean mandatory = Boolean.parseBoolean(contents[1]);
		if (isNewer(version, Configuration.getVersion())) {
			Configuration.updateChecked = true;
			Configuration.update = true;
			int confirm = JOptionPane.showConfirmDialog(null, "<html><center>"
					+ "An update for " + Configuration.NAME + "(v" + version + ") is available.<br>"
					+ (mandatory ? "This is a mandatory update; your current version is obsolete.<br>" : "")
					+ "Would you like to update?</center></html>", "Update Available!", JOptionPane.YES_NO_OPTION);
			if (confirm == JOptionPane.YES_OPTION) {
				try {
					String vstr = version.replace(".", "");
					File jar = new File(Paths.getHomeDirectory() + File.separator + Configuration.NAME + "-" + vstr + ".jar");
					if (jar.exists()) {
						jar.delete();
					}
					URL url = new URL(Paths.Resources.URLs.DOWNLOAD);
					if (!Internet.downloadAndSaveFile(url, jar)) {
						throw new IOException();
					}
					JOptionPane.showMessageDialog(null, "<html><center>"
							+ "Update downloaded successfully.<br>"
							+ "Please run " + Configuration.NAME + "-" + vstr + ".jar to apply updates.<br>"
							+ "This file is located at:<br>" + jar.getAbsolutePath() + "</center></html>",
							"Update Successful", JOptionPane.PLAIN_MESSAGE);
					FileExplorer.reveal(jar);
					Textube.exit(0);
				} catch (Exception e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "<html><center>Failed to download update.<br>"
							+ "Download the update manually at " + Configuration.Paths.Resources.URLs.HOME + "</center></html>",
							"Update Failed", JOptionPane.ERROR_MESSAGE);
					if (mandatory) {
						JOptionPane.showMessageDialog(null, "<html><center>"
								+ "Your current version of " + Configuration.NAME + " is obsolete.<br>"
								+ Configuration.NAME + " will now exit.</center></html>", "Obsolete Version", JOptionPane.WARNING_MESSAGE);
						Textube.exit(0);
					}
				}
			} else {
				if (mandatory) {
					JOptionPane.showMessageDialog(null, "<html><center>"
							+ "Your current version of " + Configuration.NAME + " is obsolete.<br>"
							+ Configuration.NAME + " will now exit.</center></html>", "Obsolete Version", JOptionPane.WARNING_MESSAGE);
					Textube.exit(0);
				}
			}
		}
	}
	
	/**
	 * Checks which version is more recent.
	 */
	private static boolean isNewer(String version1, String version2) {
		String[] parts1 = version1.split("\\.");
		String[] parts2 = version2.split("\\.");
		for (int i = 0; i < parts1.length && i < parts2.length; i++) {
			int cur1 = Integer.parseInt(parts1[i]);
			int cur2 = Integer.parseInt(parts2[i]);
			if (cur1 > cur2) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Makes necessary directories.
	 */
	public static void mkdirs() {
		String[] paths = new String[] { Paths.getHomeDirectory(), Paths.getLibDirectory() };
		for (String path : paths) {
			File dir = new File(path);
			if (!dir.isDirectory()) {
				dir.mkdirs();
			}
		}
	}
	
	/**
	 * Downloads and makes the necessary libraries.
	 */
	public static void mklibs() {
		int length = Paths.Resources.URLs.Libraries.LIBRARIES.length;
		for (int i = 0; i < length; i++) {
			try {
				File lib = new File(Paths.getHomeDirectory() + Paths.Resources.Libraries.LIBRARIES[i]);
				if (lib.exists()) {
					continue;
				}
				URL url = new URL(Paths.Resources.URLs.Libraries.LIBRARIES[i]);
				byte[] bytes = Internet.downloadBinary(url);
				lib.createNewFile();
				FileOutputStream out = new FileOutputStream(lib);
				out.write(bytes);
				out.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Checks if the runtime is secure.
	 */
	public static boolean isSecure() {
		return !hasInstrumentation() && !hasAlienXboot();
	}
	
	/**
	 * Checks if a java agent is running.
	 */
	private static boolean hasInstrumentation() {
		RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();
		List<String> args = bean.getInputArguments();
		for (String arg : args) {
			if (arg.contains("-javaagent:")) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Checks if any classes are xbooted.
	 */
	private static boolean hasAlienXboot() {
		RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();
		List<String> args = bean.getInputArguments();
		for (String arg : args) {
			if (arg.contains("-Xbootclasspath/p:")) {
				return true;
			}
		}
		return false;
	}
	
	static {
		String osName = System.getProperty("os.name");
		for (OS osValue : OS.values()) {
			if (osName.contains(osValue.getName())) {
				os = osValue;
				break;
			}
		}
	}
	
}
