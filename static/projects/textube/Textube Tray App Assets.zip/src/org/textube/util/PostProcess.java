package org.textube.util;

import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Asynchronous URL post process.
 */
public class PostProcess extends Thread {
	
	private String target = null;
	private Map<String, String> params = null;
	private File file = null;
	private double progress = 0.0;
	private String response = null;
	private boolean complete = false;
	
	/**
	 * PostProcess constructor.
	 */
	public PostProcess(String target) {
		this(target, new HashMap<String, String>(), null);
	}

	/**
	 * PostProcess constructor.
	 */
	public PostProcess(String target, Map<String, String> params) {
		this(target, params, null);
	}
	
	/**
	 * PostProcess constructor.
	 */
	public PostProcess(String target, Map<String, String> params, File file) {
		this.target = target;
		this.params = params;
		this.file = file;
	}
	
	/**
	 * Runs post process.
	 */
	@Override
	public void run() {
		try {
			upload();
		} catch (IOException e) {
			e.printStackTrace();
			Toolkit.getDefaultToolkit().beep();
		}
	}
	
	/**
	 * Connects and executes the post process.
	 */
	public void upload() throws IOException {
		URL url = new URL(target);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.disconnect();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setUseCaches(false);
		con.setRequestMethod("POST");
		con.setRequestProperty("Connection", "Keep-Alive");
		String boundary = getBoundary();
		con.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
		ByteArrayOutputStream bas = new ByteArrayOutputStream();
		String boundaryMessage = getBoundaryMessage(params, file, boundary);
		bas.write(boundaryMessage.getBytes());
		if (file != null) {
			byte[] fileBytes = getBytes(file);
			bas.write(fileBytes);
		}
		String endBoundary = "\r\n--" + boundary + "--\r\n";
		bas.write(endBoundary.getBytes());
		byte[] request = bas.toByteArray();
		int requestLength = request.length;
		con.setRequestProperty("Content-length", Integer.toString(requestLength));
		con.setFixedLengthStreamingMode((int) requestLength);
		con.connect();
		OutputStream out = con.getOutputStream();
		out.flush();
		ByteArrayInputStream bis = new ByteArrayInputStream(request);
		int read = 0;
		byte[] buffer = new byte[1024];
		while ((read = bis.read(buffer)) != -1) {
			if (isInterrupted()) {
				out.close();
				return;
			}
			out.write(buffer, 0, read);
			out.flush();
			progress += ((double) read / requestLength * 100);
		}
		out.close();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		StringBuilder input = new StringBuilder();
		String line = null;
		while ((line = in.readLine()) != null) {
			input.append(line);
		}
		in.close();
		response = input.toString();
		complete = true;
	}
	
	public void putParameter(String key, String value) {
		params.put(key, value);
	}
	
	/**
	 * Gets the post target.
	 */
	public String getTarget() {
		return target;
	}
	
	/**
	 * Gets the post parameters.
	 */
	public Map<String, String> getParameters() {
		return params;
	}
	
	/**
	 * Gets the file to upload.
	 */
	public File getFile() {
		return file;
	}
	
	/**
	 * Gets the current upload progress.
	 */
	public double getProgress() {
		return progress;
	}
	
	/**
	 * Gets the target response.
	 */
	public String getResponse() {
		return response;
	}
	
	/**
	 * Checks if the post process is complete.
	 */
	public boolean isComplete() {
		return complete;
	}

	/**
	 * Builds the post process boundary.
	 */
	private static String getBoundary() {
		return Long.toHexString(System.currentTimeMillis());
	}

	/**
	 * Builds the post process boundary message.
	 */
	private static String getBoundaryMessage(Map<String, String> params, File file, String boundary) {
		StringBuffer res = new StringBuffer("--").append(boundary).append("\r\n");
		if (params != null) {
			Iterator<String> iter = params.keySet().iterator();
			while (iter.hasNext()) {
				String key = iter.next();
				String value = params.get(key);
				res.append("Content-Disposition: form-data; name=\"").append(key).append("\"\r\n")    
						.append("\r\n").append(value).append("\r\n")
						.append("--").append(boundary).append("\r\n");
			}
		}
		if (file != null) {
			String fname = file.getName();
			res.append("Content-Disposition: form-data; name=\"").append("fileupload").append("\"; filename=\"")
					.append(fname).append("\"\r\n").append("Content-Type: ")
					.append(getMimeType(fname)).append("\r\n\r\n");
		}
		return res.toString();
	}

	/**
	 * Gets the bytes of a file.
	 */
	private static byte[] getBytes(File file) throws IOException {
		byte[] buffer = new byte[(int) file.length()];
		FileInputStream in = new FileInputStream(file);
		try {
			if (in.read(buffer) == -1) {
				throw new IOException("failed to read file");
			}
		} finally {
			in.close();
		}
		return buffer;
	}

	/**
	 * Gets the mime type of the file at the given url.
	 */
	private static String getMimeType(String fileUrl) {
		String type = URLConnection.getFileNameMap().getContentTypeFor(fileUrl);
		return type != null ? type : "application/octet-stream";
	}
	
}
