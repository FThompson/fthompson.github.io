package org.textube.util;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;

/**
 * System clipboard utilities.
 */
public class ClipboardUtil {
	
	private static Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	
	/**
	 * Sets clipboard contents.
	 */
	public static void setContents(String contents) {
		StringSelection selection = new StringSelection(contents);
		clipboard.setContents(selection, null);
	}
	
	/**
	 * Gets clipboard contents.
	 */
	public static Object getContents() {
		if (clipboard.isDataFlavorAvailable(DataFlavor.stringFlavor)) {
			return getData(DataFlavor.stringFlavor);
		} else if (clipboard.isDataFlavorAvailable(DataFlavor.javaFileListFlavor)) {
			return getData(DataFlavor.javaFileListFlavor);
		}
		return null;
	}
	
	/**
	 * Gets clipboard data of a given flavor.
	 */
	public static Object getData(DataFlavor flavor) {
		try {
			return clipboard.getData(flavor);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
