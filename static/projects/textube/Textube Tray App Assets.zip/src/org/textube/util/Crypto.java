package org.textube.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Encryption utility.
 */
public class Crypto {

	private Cipher ecipher = null;
	private Cipher dcipher = null;
	private final byte[] buf = new byte[1024];
	private static final String HEXES = "0123456789ABCDEF";

	/**
	 * Crypto constructor.
	 */
	public Crypto() {
		try {
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128);
			setupCrypto(kgen.generateKey());
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Crypto constructor with custom encryption key.
	 */
	public Crypto(String key) {
		SecretKeySpec skey = new SecretKeySpec(getMD5(key), "AES");
		setupCrypto(skey);
	}

	/**
	 * Sets up crypto.
	 */
	private void setupCrypto(SecretKey key) {
		byte[] iv = new byte[]{ 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
				0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f };
		AlgorithmParameterSpec paramSpec = new IvParameterSpec(iv);
		try {
			ecipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			dcipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			ecipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
			dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Encrypts a stream.
	 */
	public void encrypt(InputStream in, OutputStream out) {
		try {
			out = new CipherOutputStream(out, ecipher);
			int numRead = 0;
			while ((numRead = in.read(buf)) >= 0) {
				out.write(buf, 0, numRead);
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Encrypts text.
	 */
	public String encrypt(String text) {
		try {
			byte[] ciphertext = ecipher.doFinal(text.getBytes("UTF-8"));
			return byteToHex(ciphertext);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Decrypts a stream.
	 */
	public void decrypt(InputStream in, OutputStream out){
		try {
			in = new CipherInputStream(in, dcipher);
			int numRead = 0;
			while ((numRead = in.read(buf)) >= 0) {
				out.write(buf, 0, numRead);
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Decrypts text.
	 */
	public String decrypt(String hexCipherText) {
		try {
			return new String(dcipher.doFinal(hexToByte(hexCipherText)), "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Decrypts a byte array.
	 */
	public String decrypt(byte[] ciphertext) {
		try {
			return new String(dcipher.doFinal(ciphertext), "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Gets a decryption stream.
	 */
	public CipherInputStream getDecryptionStream(InputStream in) {
		return new CipherInputStream(in, dcipher);
	}
	
	/**
	 * Gets an encryption stream.
	 */
	public CipherOutputStream getEncryptionStream(OutputStream out) {
		return new CipherOutputStream(out, ecipher);
	}

	/**
	 * Creates an md5 hash byte array.
	 */
	private static byte[] getMD5(String input) {
		try {
			byte[] bytesOfMessage = input.getBytes("UTF-8");
			MessageDigest md = MessageDigest.getInstance("MD5");
			return md.digest(bytesOfMessage);
		} catch (Exception e){
			return null;
		}
	}

	/**
	 * Converts bytes to a hex string.
	 */
	public static String byteToHex(byte[] raw) {
		if (raw == null) {
			return null;
		}
		StringBuilder hex = new StringBuilder(2 * raw.length);
		for (byte b : raw) {
			hex.append(HEXES.charAt((b & 0xF0) >> 4)).append(HEXES.charAt((b & 0x0F)));
		}
		return hex.toString();
	}

	/**
	 * Converts a hex string to bytes.
	 */
	public static byte[] hexToByte(String hexString){
		int len = hexString.length();
		byte[] ba = new byte[len / 2];
		for (int i = 0; i < len - 1; i += 2) {
			ba[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
					+ Character.digit(hexString.charAt(i + 1), 16));
		}
		return ba;
	}
	
	/**
	 * Creates an md5 hash string.
	 */
	public static String md5(char[] input) {
		byte[] bytes = getMD5(new String(input));
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bytes.length; i++) {
			sb.append(Integer.toHexString((bytes[i] & 0xFF) | 0x100).substring(1, 3));
		}
		return sb.toString();
	}
}
