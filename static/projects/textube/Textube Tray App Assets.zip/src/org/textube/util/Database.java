package org.textube.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Properties;

/**
 * Application properties database.
 */
public class Database {
	
	private static Crypto crypto = null;
	private static Properties cached = null;
	
	/**
	 * Gets a property value.
	 */
	public static String getProperty(String key) {
		return cached.getProperty(key);
	}
	
	/**
	 * Sets a property value.
	 */
	public static void setProperty(String key, String value) {
		cached.setProperty(key, value);
	}
	
	/**
	 * Removes a property value.
	 */
	public static void remove(String key) {
		cached.remove(key);
	}
	
	/**
	 * Stores property values to the database file, creating it if necessary.
	 */
	public static void store() {
		File appData = new File(Configuration.Paths.getDatabaseFile());
		if (!appData.exists()) {
			try {
				appData.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("unable to create database");
				return;
			}
		}
		if (!appData.canWrite()) {
			appData.setWritable(true);
		}
        try {
        	ByteArrayOutputStream bout = new ByteArrayOutputStream();
        	ObjectOutputStream oout = new ObjectOutputStream(bout);
        	oout.writeObject(cached);
        	ByteArrayInputStream bin = new ByteArrayInputStream(bout.toByteArray());
        	FileOutputStream out = new FileOutputStream(appData);
        	crypto.encrypt(bin, out);
        	oout.close();
        	out.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("failed to store database");
		}
	}
	
	/**
	 * Loads property values from the database file.
	 */
	private static void load() {
		File appData = new File(Configuration.Paths.getDatabaseFile());
		if (appData.exists()) {
			if (!appData.canRead()) {
				appData.setReadable(true);
			}
			try {
				FileInputStream fin = new FileInputStream(appData);
				ByteArrayOutputStream bout = new ByteArrayOutputStream();
				crypto.decrypt(fin, bout);
				ByteArrayInputStream bin = new ByteArrayInputStream(bout.toByteArray());
				ObjectInputStream in = new ObjectInputStream(bin);
				cached = (Properties) in.readObject();
				fin.close();
				in.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("failed to load database");
			}
		}
	}
	
	static {
		crypto = new Crypto("gdsag" + Configuration.Paths.getDatabaseFile() + "asdaas");
		cached = new Properties();
		load();
	}

}
