package org.textube;

import java.awt.TrayIcon;
import java.io.IOException;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.pushingpixels.substance.api.skin.SubstanceRavenLookAndFeel;
import org.textube.jna.SystemKeyboard;
import org.textube.tools.ToolKeyListener;
import org.textube.ui.Tray;
import org.textube.util.Configuration;

/**
 * Application main class.
 */
public class Textube {
	
	private static Tray tray = null;
	private static boolean responded = false;
	
	/**
	 * Application main method. 
	 */
	public static void main(String[] args) throws Exception {
		if (new Throwable().getStackTrace().length > 1 || !Configuration.isSecure()) {
			throw new IOException();
		}
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(new SubstanceRavenLookAndFeel());
				} catch (UnsupportedLookAndFeelException e) {
					e.printStackTrace();
				}
			}
		});
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Configuration.applyUpdates();
				Configuration.updateChecked = true;
				responded = true;
			}
		});
		while (!Configuration.updateChecked) {
			Thread.sleep(100);
		}
		if (Configuration.update) {
			while (!responded) {
				Thread.sleep(100);
			}
		}
		tray = new Tray();
		tray.initialize();
		if (Configuration.getOS().equals(Configuration.OS.WINDOWS)) {
			ToolKeyListener listener = new ToolKeyListener();
			SystemKeyboard.addListener(listener);
			SystemKeyboard.run();
		}
		tray.displayMessage(Configuration.NAME, "Initialization complete.", TrayIcon.MessageType.INFO);
	}
	
	/**
	 * Accessor for tray instance.
	 */
	public static Tray getTray() {
		return tray;
	}
	
	/**
	 * JVM exit handler.
	 */
	public static void exit(int status) {
		SystemKeyboard.unhook();
		if (tray != null) {
			tray.remove();
		}
		System.exit(status);
	}
	
}
