package org.textube.jna;

import java.awt.event.KeyListener;

import javax.swing.JDialog;
import javax.swing.SwingUtilities;

import com.sun.jna.Native;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinUser;
import com.sun.jna.platform.win32.WinDef.HMODULE;
import com.sun.jna.platform.win32.WinUser.HHOOK;
import com.sun.jna.platform.win32.WinUser.MSG;

/**
 * System keyboard handler, using JNA.
 */
public class SystemKeyboard {

	private static HHOOK hhk = null;
	private static User32 lib = null;
	private static HMODULE hMod = null;
	private static KeyboardHook hook = new KeyboardHook();

	/**
	 * Runs the threaded system keyboard hook and handler.
	 */
	public static void run() {
		Thread thread = new Thread(new Runnable() {
			public void run() {
				lib = User32.INSTANCE;
				hMod = Kernel32.INSTANCE.GetModuleHandle(null);
				Native.setProtected(true);
				hhk = lib.SetWindowsHookEx(WinUser.WH_KEYBOARD_LL, hook, hMod, 0);
				hook.setLib(lib);
				hook.setHHOOK(hhk);
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JDialog temp = new JDialog();
						temp.setVisible(true);
						temp.dispose();
					}
				});
				int result;
				MSG msg = new MSG();
				while ((result = lib.GetMessage(msg, null, 0, 0)) != 0) {
					if (result == -1) {
						break;
					} else {
						lib.TranslateMessage(msg);
						lib.DispatchMessage(msg);
					}
				}
				unhook();
			}
		});
		thread.start();
	}

	/**
	 * Unhooks the system keyboard.
	 */
	public static void unhook() {
		if (lib != null) {
			lib.UnhookWindowsHookEx(hhk);
		}
	}

	/**
	 * Adds a key listener to the keyboard hook.
	 */
	public static void addListener(KeyListener listener) {
		hook.addListener(listener);
	}

	/**
	 * Removes a key listener from the keyboard hook.
	 */
	public static void removeListener(KeyListener listener) {
		hook.removeListener(listener);
	}

	/**
	 * Removes all key listeners from the keyboard hook.
	 */
	public static void clearListeners() {
		hook.clearListeners();
	}
}
