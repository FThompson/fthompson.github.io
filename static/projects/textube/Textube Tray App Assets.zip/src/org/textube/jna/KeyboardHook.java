package org.textube.jna;

import java.awt.Component;
import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.List;

import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinUser;
import com.sun.jna.platform.win32.WinDef.LRESULT;
import com.sun.jna.platform.win32.WinDef.WPARAM;
import com.sun.jna.platform.win32.WinUser.HHOOK;
import com.sun.jna.platform.win32.WinUser.KBDLLHOOKSTRUCT;
import com.sun.jna.platform.win32.WinUser.LowLevelKeyboardProc;

/**
 * Keyboard hook for the system keyboard.
 */
public class KeyboardHook implements LowLevelKeyboardProc {

	private HHOOK hhk = null;
	private User32 lib = null;
	private boolean altDown = false;
	private boolean altGraphDown = false;
	private boolean ctrlDown = false;
	private boolean metaDown = false;
	private boolean shiftDown = false;
	private static Component component = new Frame();
	private static List<KeyListener> listeners = new ArrayList<KeyListener>();

	/**
	 * Handles the callback of a native library key event, passing it to java key listeners.
	 */
	public LRESULT callback(int nCode, WPARAM wParam, KBDLLHOOKSTRUCT info) {
		if (nCode >= 0) {
			switch (wParam.intValue()) {
			case WinUser.WM_KEYUP:
			case WinUser.WM_SYSKEYUP:
				switch (info.vkCode) {
				case KeyEvent.VK_ALT:
				case 164:
				case 165:
					altDown = false;
					break;
				case KeyEvent.VK_ALT_GRAPH:
					altGraphDown = false;
					break;
				case KeyEvent.VK_CONTROL:
				case 162:
				case 163:
					ctrlDown = false;
					break;
				case KeyEvent.VK_META:
					metaDown = false;
					break;
				case KeyEvent.VK_SHIFT:
				case 160:
				case 161:
					shiftDown = false;
					break;
				}
				KeyEvent releaseEvent = new KeyEvent(component, KeyEvent.KEY_RELEASED, System.currentTimeMillis(), getModifiers(), info.vkCode, getKeyChar((char) info.vkCode));
				for (KeyListener listener : listeners) {
					listener.keyReleased(releaseEvent);
				}
				break;
			case WinUser.WM_KEYDOWN:
			case WinUser.WM_SYSKEYDOWN:
				switch (info.vkCode) {
				case KeyEvent.VK_ALT:
				case 164:
				case 165:
					altDown = true;
					break;
				case KeyEvent.VK_ALT_GRAPH:
					altGraphDown = true;
					break;
				case KeyEvent.VK_CONTROL:
				case 162:
				case 163:
					ctrlDown = true;
					break;
				case KeyEvent.VK_META:
					metaDown = true;
					break;
				case KeyEvent.VK_SHIFT:
				case 160:
				case 161:
					shiftDown = true;
					break;
				}
				KeyEvent pressEvent = new KeyEvent(component, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), getModifiers(), info.vkCode, getKeyChar((char) info.vkCode));
				for (KeyListener listener : listeners) {
					listener.keyPressed(pressEvent);
				}
				break;
			}
		}
		return lib.CallNextHookEx(hhk, nCode, wParam, info.getPointer());
	}

	/**
	 * Sets the hook's User32 library.
	 */
	public void setLib(User32 lib) {
		this.lib = lib;
	}

	/**
	 * Sets the hook's HHOOK.
	 */
	public void setHHOOK(HHOOK hhk) {
		this.hhk = hhk;
	}

	/**
	 * Gets the current key modifiers of the system keyboard.
	 */
	private int getModifiers() {
		int modifiers = 0;
		if (altDown) {
			modifiers |= KeyEvent.ALT_DOWN_MASK;
		}
		if (altGraphDown) {
			modifiers |= KeyEvent.ALT_GRAPH_DOWN_MASK;
		}
		if (ctrlDown) {
			modifiers |= KeyEvent.CTRL_DOWN_MASK;
		}
		if (metaDown) {
			modifiers |= KeyEvent.META_DOWN_MASK;
		}
		if (shiftDown) {
			modifiers |= KeyEvent.SHIFT_DOWN_MASK;
		}
		return modifiers;
	}

	/**
	 * Gets the key event key char of a given char.
	 */
	private char getKeyChar(final char c) {
		if ((c >= 36) && (c <= 40)) {
			return KeyEvent.VK_UNDEFINED;
		} else {
			return c;
		}
	}

	/**
	 * Adds a key listener to the system keyboard.
	 */
	public void addListener(KeyListener listener) {
		listeners.add(listener);
	}

	/**
	 * Removes a key listener from the system keyboard.
	 */
	public void removeListener(KeyListener listener) {
		listeners.remove(listener);
	}

	/**
	 * Removes all key listeners from the system keyboard.
	 */
	public void clearListeners() {
		listeners.clear();
	}
}
